/*
Star Icons for Obsidian — built 2026-08-16T09:49:46.826Z
MIT License
*/
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/main.ts
var main_exports = {};
__export(main_exports, {
  StarIconsPlugin: () => StarIconsPlugin,
  default: () => main_default
});
module.exports = __toCommonJS(main_exports);
var import_obsidian13 = require("obsidian");

// src/core/applier.ts
var import_obsidian2 = require("obsidian");

// src/data/packs/star.ts
var STAR_ICONS = [
  {
    name: "star-sparkle",
    tags: ["star", "sparkle", "brand", "logo"],
    viewBox: "0 0 24 24",
    svg: `
    <path d="M12 2.8l2.1 4.6 5 .7-3.6 3.5.9 5-4.4-2.3-4.4 2.3.9-5-3.6-3.5 5-.7L12 2.8z"/>
    <path d="M18.5 3.5l.4.9.9.4-.9.4-.4.9-.4-.9-.9-.4.9-.4.4-.9z" fill="currentColor" stroke="none"/>
    <path d="M6 16l.5 1.1 1.1.5-1.1.5L6 19.2l-.5-1.1-1.1-.5 1.1-.5L6 16z" fill="currentColor" stroke="none"/>`.trim()
  },
  {
    name: "star-filled",
    tags: ["star", "filled", "solid", "rating"],
    viewBox: "0 0 24 24",
    svg: `
    <path d="M12 2.6l2.9 5.9 6.5 1-4.7 4.6 1.1 6.5L12 17.5l-5.8 3.1 1.1-6.5-4.7-4.6 6.5-1L12 2.6z" fill="currentColor" stroke="none"/>`.trim()
  },
  {
    name: "star-badge",
    tags: ["star", "badge", "medal", "award"],
    viewBox: "0 0 24 24",
    svg: `
    <circle cx="12" cy="12" r="8.5"/>
    <path d="M12 6.8l1.7 3.4 3.8.5-2.7 2.7.6 3.8L12 15.7l-3.4 1.5.6-3.8-2.7-2.7 3.8-.5L12 6.8z"/>`.trim()
  },
  {
    name: "star-cross",
    tags: ["star", "cross", "compass", "rose", "navigation"],
    viewBox: "0 0 24 24",
    svg: `
    <path d="M12 2.5v19M2.5 12h19M5.3 5.3l13.4 13.4M18.7 5.3L5.3 18.7"/>
    <path d="M12 2.5L13.5 10.5 21.5 12 13.5 13.5 12 21.5 10.5 13.5 2.5 12 10.5 10.5 12 2.5z"/>`.trim()
  },
  {
    name: "comet",
    tags: ["comet", "space", "star", "tail"],
    viewBox: "0 0 24 24",
    svg: `
    <circle cx="16.5" cy="7.5" r="4.2"/>
    <path d="M2.5 21.5c4.5-6.5 9-10.5 13-12.5"/>
    <path d="M2.5 21.5c5-.5 9.5-2 12.5-4.5"/>
    <path d="M2.5 21.5c4-3 7-4.5 10-5.5"/>`.trim()
  },
  {
    name: "constellation",
    tags: ["constellation", "stars", "space", "connect"],
    viewBox: "0 0 24 24",
    svg: `
    <path d="M5 5l4 3-2 5 4 2"/>
    <path d="M11 15l6-9"/>
    <path d="M19 12l-8 3"/>
    <circle cx="5" cy="5" r="1.7"/>
    <circle cx="9" cy="8" r="1.7"/>
    <circle cx="7" cy="13" r="1.7"/>
    <circle cx="11" cy="15" r="1.7"/>
    <circle cx="17" cy="6" r="1.7"/>
    <circle cx="19" cy="12" r="1.7"/>`.trim()
  },
  {
    name: "galaxy",
    tags: ["galaxy", "space", "spiral", "cosmos"],
    viewBox: "0 0 24 24",
    svg: `
    <path d="M12 3a9 9 0 0 1 9 9 6.5 6.5 0 0 1-6.5 6.5A4.5 4.5 0 0 1 10 14a3 3 0 0 1 3-3"/>
    <path d="M3 12a9 9 0 0 0 9 9 6 6 0 0 0 6-6"/>
    <circle cx="7.5" cy="6.5" r="0.7" fill="currentColor" stroke="none"/>
    <circle cx="17" cy="17.5" r="0.7" fill="currentColor" stroke="none"/>
    <circle cx="5" cy="15.5" r="0.7" fill="currentColor" stroke="none"/>`.trim()
  },
  {
    name: "orbit",
    tags: ["orbit", "satellite", "space", "orbit"],
    viewBox: "0 0 24 24",
    svg: `
    <ellipse cx="12" cy="12" rx="9" ry="4" transform="rotate(-24 12 12)"/>
    <circle cx="12" cy="12" r="2.2"/>
    <circle cx="19.8" cy="9.6" r="1.5"/>
    <path d="M4.5 14.5c-.8 2.5-.3 4.8 1.5 6" opacity="0.5"/>`.trim()
  },
  {
    name: "shooting-star",
    tags: ["shooting", "star", "falling", "wish"],
    viewBox: "0 0 24 24",
    svg: `
    <path d="M19 5.5L6.5 18"/>
    <path d="M19 5.5l-5.6.8 4.8 4.8.8-5.6z"/>
    <path d="M14 14.5c-2.5 2.5-5.5 4-9 4.5"/>
    <path d="M3.5 19c.7-1.5 1.7-2.7 3-3.5"/>`.trim()
  },
  {
    name: "nova",
    tags: ["nova", "star", "burst", "explosion", "flash"],
    viewBox: "0 0 24 24",
    svg: `
    <path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M18.4 5.6l-2.1 2.1M7.7 16.3l-2.1 2.1"/>
    <path d="M12 7.2l1.4 2.9 3.2.5-2.3 2.3.6 3.2L12 14.6l-2.9 1.5.6-3.2-2.3-2.3 3.2-.5L12 7.2z"/>`.trim()
  },
  {
    name: "satellite",
    tags: ["satellite", "space", "antenna", "signal"],
    viewBox: "0 0 24 24",
    svg: `
    <rect x="7.5" y="7.5" width="9" height="9" rx="1.5"/>
    <path d="M10.5 4.5h3M12 4.5V3"/>
    <path d="M4.5 10.5h-1.5M4.5 13.5h-1.5M19.5 10.5h1.5M19.5 13.5h1.5"/>
    <path d="M9 13.5l3 3 3-3"/>`.trim()
  },
  {
    name: "meteor",
    tags: ["meteor", "space", "fire", "falling"],
    viewBox: "0 0 24 24",
    svg: `
    <circle cx="15" cy="9" r="4.5"/>
    <path d="M15 4.5V3"/>
    <path d="M12.2 6.2L10.5 4.5"/>
    <path d="M17.8 6.2L19.5 4.5"/>
    <path d="M10 12.5c-3.5 2.5-6 5-7 8"/>
    <path d="M10.5 13.5c-2.8 2-4.5 4-5 6.5"/>`.trim()
  },
  {
    name: "star-wand",
    tags: ["wand", "magic", "star", "sparkle"],
    viewBox: "0 0 24 24",
    svg: `
    <path d="M15 4l5 5-3.5 3.5-5-5L15 4z"/>
    <path d="M13.5 5.5L5 14v5h5l8.5-8.5"/>
    <path d="M8 5.5l.6 1.4 1.4.6-1.4.6L8 9.5l-.6-1.4L6 7.5l1.4-.6L8 5.5z" fill="currentColor" stroke="none"/>`.trim()
  },
  {
    name: "supernova",
    tags: ["supernova", "star", "rings", "explosion"],
    viewBox: "0 0 24 24",
    svg: `
    <circle cx="12" cy="12" r="2.2"/>
    <path d="M12 2.5l1.3 2.7 3 .4-2.2 2.1.5 3-2.6-1.4-2.6 1.4.5-3-2.2-2.1 3-.4L12 2.5z"/>
    <circle cx="12" cy="12" r="6" opacity="0.6"/>
    <circle cx="12" cy="12" r="9.5" opacity="0.35"/>`.trim()
  }
];

// src/data/packs/emoji.ts
var ANIMALS_ICONS = [
  { name: "dog", emoji: "\u{1F436}", tags: ["pet", "puppy", "canine"] },
  { name: "cat", emoji: "\u{1F431}", tags: ["pet", "kitten", "feline"] },
  { name: "mouse", emoji: "\u{1F42D}", tags: ["pet", "rodent"] },
  { name: "hamster", emoji: "\u{1F439}", tags: ["pet", "rodent"] },
  { name: "rabbit", emoji: "\u{1F430}", tags: ["bunny", "pet"] },
  { name: "fox", emoji: "\u{1F98A}", tags: ["wild", "canine"] },
  { name: "bear", emoji: "\u{1F43B}", tags: ["wild", "forest"] },
  { name: "polar-bear", emoji: "\u{1F43B}\u200D\u2744\uFE0F", tags: ["wild", "arctic", "ice"] },
  { name: "panda", emoji: "\u{1F43C}", tags: ["bear", "bamboo"] },
  { name: "koala", emoji: "\u{1F428}", tags: ["bear", "australia"] },
  { name: "tiger", emoji: "\u{1F42F}", tags: ["wild", "big-cat"] },
  { name: "lion", emoji: "\u{1F981}", tags: ["wild", "big-cat", "king"] },
  { name: "cow", emoji: "\u{1F42E}", tags: ["farm", "livestock"] },
  { name: "pig", emoji: "\u{1F437}", tags: ["farm", "livestock"] },
  { name: "boar", emoji: "\u{1F417}", tags: ["wild"] },
  { name: "frog", emoji: "\u{1F438}", tags: ["amphibian", "pond"] },
  { name: "monkey", emoji: "\u{1F435}", tags: ["primate", "jungle"] },
  { name: "gorilla", emoji: "\u{1F98D}", tags: ["primate", "jungle"] },
  { name: "orangutan", emoji: "\u{1F9A7}", tags: ["primate", "ape"] },
  { name: "chimpanzee", emoji: "\u{1F412}", tags: ["primate", "ape"] },
  { name: "chicken", emoji: "\u{1F414}", tags: ["farm", "poultry"] },
  { name: "rooster", emoji: "\u{1F413}", tags: ["farm", "poultry"] },
  { name: "baby-chick", emoji: "\u{1F423}", tags: ["poultry", "spring"] },
  { name: "chick", emoji: "\u{1F424}", tags: ["poultry", "spring"] },
  { name: "bird", emoji: "\u{1F426}", tags: ["songbird"] },
  { name: "penguin", emoji: "\u{1F427}", tags: ["arctic", "bird"] },
  { name: "duck", emoji: "\u{1F986}", tags: ["waterfowl", "pond"] },
  { name: "eagle", emoji: "\u{1F985}", tags: ["raptor", "bird-of-prey"] },
  { name: "owl", emoji: "\u{1F989}", tags: ["raptor", "night"] },
  { name: "bat", emoji: "\u{1F987}", tags: ["night", "mammal"] },
  { name: "wolf", emoji: "\u{1F43A}", tags: ["wild", "canine"] },
  { name: "horse", emoji: "\u{1F434}", tags: ["farm", "equine"] },
  { name: "unicorn", emoji: "\u{1F984}", tags: ["fantasy", "magic"] },
  { name: "bee", emoji: "\u{1F41D}", tags: ["insect", "honey"] },
  { name: "caterpillar", emoji: "\u{1F41B}", tags: ["insect", "garden"] },
  { name: "butterfly", emoji: "\u{1F98B}", tags: ["insect", "garden"] },
  { name: "snail", emoji: "\u{1F40C}", tags: ["garden", "mollusk"] },
  { name: "ladybug", emoji: "\u{1F41E}", tags: ["insect", "garden"] },
  { name: "ant", emoji: "\u{1F41C}", tags: ["insect"] },
  { name: "beetle", emoji: "\u{1FAB2}", tags: ["insect"] },
  { name: "cricket", emoji: "\u{1F997}", tags: ["insect"] },
  { name: "spider", emoji: "\u{1F577}\uFE0F", tags: ["arachnid"] },
  { name: "scorpion", emoji: "\u{1F982}", tags: ["arachnid", "desert"] },
  { name: "turtle", emoji: "\u{1F422}", tags: ["reptile", "slow"] },
  { name: "snake", emoji: "\u{1F40D}", tags: ["reptile"] },
  { name: "lizard", emoji: "\u{1F98E}", tags: ["reptile"] },
  { name: "t-rex", emoji: "\u{1F996}", tags: ["dinosaur", "prehistoric"] },
  { name: "dinosaur", emoji: "\u{1F995}", tags: ["dinosaur", "prehistoric"] },
  { name: "octopus", emoji: "\u{1F419}", tags: ["sea", "ocean"] },
  { name: "squid", emoji: "\u{1F991}", tags: ["sea", "ocean"] },
  { name: "shrimp", emoji: "\u{1F990}", tags: ["sea", "seafood"] },
  { name: "lobster", emoji: "\u{1F99E}", tags: ["sea", "seafood"] },
  { name: "crab", emoji: "\u{1F980}", tags: ["sea", "seafood"] },
  { name: "blowfish", emoji: "\u{1F421}", tags: ["fish", "sea"] },
  { name: "fish", emoji: "\u{1F41F}", tags: ["fish", "sea"] },
  { name: "tropical-fish", emoji: "\u{1F420}", tags: ["fish", "aquarium"] },
  { name: "dolphin", emoji: "\u{1F42C}", tags: ["mammal", "sea"] },
  { name: "whale", emoji: "\u{1F433}", tags: ["mammal", "sea"] },
  { name: "shark", emoji: "\u{1F988}", tags: ["fish", "sea"] },
  { name: "crocodile", emoji: "\u{1F40A}", tags: ["reptile"] },
  { name: "leopard", emoji: "\u{1F406}", tags: ["wild", "big-cat"] },
  { name: "buffalo", emoji: "\u{1F9AC}", tags: ["wild", "livestock"] },
  { name: "ox", emoji: "\u{1F402}", tags: ["farm", "zodiac"] },
  { name: "ram", emoji: "\u{1F40F}", tags: ["farm", "zodiac"] },
  { name: "sheep", emoji: "\u{1F411}", tags: ["farm", "wool"] },
  { name: "goat", emoji: "\u{1F410}", tags: ["farm", "zodiac"] },
  { name: "camel", emoji: "\u{1F42A}", tags: ["desert"] },
  { name: "llama", emoji: "\u{1F999}", tags: ["farm", "andes"] },
  { name: "giraffe", emoji: "\u{1F992}", tags: ["wild", "savanna"] },
  { name: "elephant", emoji: "\u{1F418}", tags: ["wild", "savanna"] },
  { name: "mammoth", emoji: "\u{1F9A3}", tags: ["prehistoric", "ice-age"] },
  { name: "rhinoceros", emoji: "\u{1F98F}", tags: ["wild", "savanna"] },
  { name: "hippopotamus", emoji: "\u{1F99B}", tags: ["wild", "river"] },
  { name: "kangaroo", emoji: "\u{1F998}", tags: ["australia", "marsupial"] },
  { name: "rat", emoji: "\u{1F400}", tags: ["rodent"] },
  { name: "turkey", emoji: "\u{1F983}", tags: ["farm", "poultry"] },
  { name: "peacock", emoji: "\u{1F99A}", tags: ["bird", "colorful"] },
  { name: "parrot", emoji: "\u{1F99C}", tags: ["bird", "tropical"] },
  { name: "swan", emoji: "\u{1F9A2}", tags: ["waterfowl"] },
  { name: "flamingo", emoji: "\u{1F9A9}", tags: ["bird", "tropical"] },
  { name: "dove", emoji: "\u{1F54A}\uFE0F", tags: ["bird", "peace"] },
  { name: "otter", emoji: "\u{1F9A6}", tags: ["river", "mammal"] },
  { name: "skunk", emoji: "\u{1F9A8}", tags: ["wild"] },
  { name: "badger", emoji: "\u{1F9A1}", tags: ["wild"] },
  { name: "hedgehog", emoji: "\u{1F994}", tags: ["garden", "mammal"] },
  { name: "squirrel", emoji: "\u{1F43F}\uFE0F", tags: ["forest", "rodent"] },
  { name: "beaver", emoji: "\u{1F9AB}", tags: ["river", "rodent"] },
  { name: "seal", emoji: "\u{1F9AD}", tags: ["sea", "mammal"] },
  { name: "sloth", emoji: "\u{1F9A5}", tags: ["jungle", "slow"] },
  { name: "dodo", emoji: "\u{1F9A4}", tags: ["extinct", "bird"] },
  { name: "goose", emoji: "\u{1FABF}", tags: ["farm", "waterfowl"] },
  { name: "jellyfish", emoji: "\u{1FABC}", tags: ["sea", "ocean"] },
  { name: "feather", emoji: "\u{1FAB6}", tags: ["bird", "flight"] },
  { name: "paw-prints", emoji: "\u{1F43E}", tags: ["track", "pet"] }
];
var NATURE_ICONS = [
  { name: "rose", emoji: "\u{1F339}", tags: ["flower", "garden", "romance"] },
  { name: "wilted-rose", emoji: "\u{1F940}", tags: ["flower", "wilted"] },
  { name: "hibiscus", emoji: "\u{1F33A}", tags: ["flower", "tropical"] },
  { name: "sunflower", emoji: "\u{1F33B}", tags: ["flower", "summer"] },
  { name: "blossom", emoji: "\u{1F33C}", tags: ["flower", "spring"] },
  { name: "tulip", emoji: "\u{1F337}", tags: ["flower", "spring", "holland"] },
  { name: "cherry-blossom", emoji: "\u{1F338}", tags: ["flower", "sakura", "spring"] },
  { name: "lotus", emoji: "\u{1FAB7}", tags: ["flower", "pond"] },
  { name: "white-flower", emoji: "\u{1F4AE}", tags: ["flower", "stamp"] },
  { name: "rosette", emoji: "\u{1F3F5}\uFE0F", tags: ["flower", "decoration"] },
  { name: "bouquet", emoji: "\u{1F490}", tags: ["flowers", "gift"] },
  { name: "seedling", emoji: "\u{1F331}", tags: ["plant", "grow", "spring"] },
  { name: "potted-plant", emoji: "\u{1FAB4}", tags: ["plant", "home"] },
  { name: "evergreen", emoji: "\u{1F332}", tags: ["tree", "forest"] },
  { name: "deciduous", emoji: "\u{1F333}", tags: ["tree", "forest"] },
  { name: "palm", emoji: "\u{1F334}", tags: ["tree", "tropical", "beach"] },
  { name: "cactus", emoji: "\u{1F335}", tags: ["plant", "desert"] },
  { name: "sheaf-of-rice", emoji: "\u{1F33E}", tags: ["grain", "farm"] },
  { name: "herb", emoji: "\u{1F33F}", tags: ["plant", "herb"] },
  { name: "shamrock", emoji: "\u2618\uFE0F", tags: ["clover", "ireland", "luck"] },
  { name: "four-leaf-clover", emoji: "\u{1F340}", tags: ["clover", "luck"] },
  { name: "maple-leaf", emoji: "\u{1F341}", tags: ["leaf", "autumn", "canada"] },
  { name: "fallen-leaf", emoji: "\u{1F342}", tags: ["leaf", "autumn"] },
  { name: "leaf", emoji: "\u{1F343}", tags: ["leaf", "wind"] },
  { name: "mushroom", emoji: "\u{1F344}", tags: ["fungus", "forest"] },
  { name: "chestnut", emoji: "\u{1F330}", tags: ["nut", "autumn"] },
  { name: "shell", emoji: "\u{1F41A}", tags: ["sea", "beach"] },
  { name: "rock", emoji: "\u{1FAA8}", tags: ["stone", "nature"] },
  { name: "wood", emoji: "\u{1FAB5}", tags: ["forest", "log"] },
  { name: "bamboo", emoji: "\u{1F38D}", tags: ["plant", "japan"] },
  { name: "pine-decoration", emoji: "\u{1F384}", tags: ["tree", "christmas"] }
];
var SCIENCE_ICONS = [
  { name: "microscope", emoji: "\u{1F52C}", tags: ["lab", "research", "biology"] },
  { name: "telescope", emoji: "\u{1F52D}", tags: ["space", "astronomy"] },
  { name: "test-tube", emoji: "\u{1F9EA}", tags: ["lab", "chemistry", "experiment"] },
  { name: "petri-dish", emoji: "\u{1F9EB}", tags: ["lab", "biology"] },
  { name: "dna", emoji: "\u{1F9EC}", tags: ["genetics", "biology"] },
  { name: "alembic", emoji: "\u2697\uFE0F", tags: ["chemistry", "distill"] },
  { name: "atom", emoji: "\u269B\uFE0F", tags: ["physics", "nuclear"] },
  { name: "microbe", emoji: "\u{1F9A0}", tags: ["germ", "virus", "bacteria"] },
  { name: "magnet", emoji: "\u{1F9F2}", tags: ["physics", "magnetism"] },
  { name: "abacus", emoji: "\u{1F9EE}", tags: ["math", "calculator"] },
  { name: "thermometer", emoji: "\u{1F321}\uFE0F", tags: ["temperature", "weather"] },
  { name: "syringe", emoji: "\u{1F489}", tags: ["medicine", "vaccine"] },
  { name: "pill", emoji: "\u{1F48A}", tags: ["medicine", "pharmacy"] },
  { name: "stethoscope", emoji: "\u{1FA7A}", tags: ["medicine", "doctor"] },
  { name: "bone", emoji: "\u{1F9B4}", tags: ["anatomy", "skeleton"] },
  { name: "brain", emoji: "\u{1F9E0}", tags: ["anatomy", "mind"] },
  { name: "anatomical-heart", emoji: "\u{1FAC0}", tags: ["anatomy", "heart"] },
  { name: "lungs", emoji: "\u{1FAC1}", tags: ["anatomy", "breathing"] },
  { name: "eye", emoji: "\u{1F441}\uFE0F", tags: ["anatomy", "vision"] },
  { name: "ear", emoji: "\u{1F442}", tags: ["anatomy", "hearing"] },
  { name: "tooth", emoji: "\u{1F9B7}", tags: ["anatomy", "dental"] },
  { name: "foot", emoji: "\u{1F9B6}", tags: ["anatomy"] },
  { name: "leg", emoji: "\u{1F9B5}", tags: ["anatomy"] },
  { name: "muscle", emoji: "\u{1F4AA}", tags: ["anatomy", "strength"] },
  { name: "lightbulb", emoji: "\u{1F4A1}", tags: ["idea", "energy"] },
  { name: "battery", emoji: "\u{1F50B}", tags: ["energy", "power"] },
  { name: "electric-plug", emoji: "\u{1F50C}", tags: ["energy", "electricity"] },
  { name: "gear", emoji: "\u2699\uFE0F", tags: ["mechanics", "settings"] },
  { name: "satellite", emoji: "\u{1F6F0}\uFE0F", tags: ["space", "orbit"] },
  { name: "rocket", emoji: "\u{1F680}", tags: ["space", "launch"] },
  { name: "flying-saucer", emoji: "\u{1F6F8}", tags: ["space", "ufo"] },
  { name: "robot", emoji: "\u{1F916}", tags: ["ai", "tech"] },
  { name: "satellite-antenna", emoji: "\u{1F4E1}", tags: ["signal", "radar"] },
  { name: "ruler", emoji: "\u{1F4CF}", tags: ["math", "measure"] },
  { name: "protractor", emoji: "\u{1F4D0}", tags: ["math", "geometry"] },
  { name: "magnifying-glass", emoji: "\u{1F50D}", tags: ["search", "inspect"] },
  { name: "crystal-ball", emoji: "\u{1F52E}", tags: ["future", "mystic"] },
  { name: "infinity", emoji: "\u267E\uFE0F", tags: ["math", "limit"] },
  { name: "radioactive", emoji: "\u2622\uFE0F", tags: ["hazard", "nuclear"] },
  { name: "biohazard", emoji: "\u2623\uFE0F", tags: ["hazard", "safety"] },
  { name: "saturn", emoji: "\u{1FA90}", tags: ["planet", "space"] },
  { name: "milky-way", emoji: "\u{1F30C}", tags: ["space", "galaxy"] },
  { name: "comet", emoji: "\u2604\uFE0F", tags: ["space", "asteroid"] },
  { name: "globe", emoji: "\u{1F30D}", tags: ["earth", "planet"] },
  { name: "moon", emoji: "\u{1F319}", tags: ["moon", "night"] },
  { name: "full-moon", emoji: "\u{1F315}", tags: ["moon", "night"] },
  { name: "explosion", emoji: "\u{1F4A5}", tags: ["boom", "impact"] }
];
var EMOJI_PACKS = {
  animals: ANIMALS_ICONS,
  nature: NATURE_ICONS,
  science: SCIENCE_ICONS
};

// src/types.ts
var ALL_PACKS = [
  "lucide",
  "material",
  "material-outlined",
  "material-sharp",
  "star",
  "tabler",
  "tabler-filled",
  "unicons",
  "unicons-solid",
  "unicons-monochrome",
  "unicons-thinline",
  "remix",
  "phosphor",
  "phosphor-bold",
  "phosphor-fill",
  "phosphor-light",
  "phosphor-thin",
  "phosphor-duotone",
  "bootstrap",
  "boxicons",
  "boxicons-solid",
  "boxicons-logos",
  "heroicons",
  "heroicons-solid",
  "fontawesome",
  "simple-icons",
  "ionicons",
  "antd",
  "line-awesome",
  "eva",
  "octicons",
  "cssgg",
  "openmoji",
  "openmoji-black",
  "twemoji",
  "fluent",
  "animals",
  "nature",
  "science"
];
var DEFAULT_REPORT_URL = "https://github.com/Stef4678/star-icons/issues";
var DEFAULT_SETTINGS = {
  fileExplorerIcons: true,
  tabIcons: true,
  inlineTitleIcons: false,
  inlineTitleEditMode: false,
  showSourceTooltips: true,
  statusBarIndicator: true,
  enabledPacks: {
    // Core library — on by default.
    lucide: true,
    material: true,
    star: true,
    tabler: true,
    "tabler-filled": true,
    unicons: true,
    remix: true,
    phosphor: true,
    bootstrap: true,
    boxicons: true,
    heroicons: true,
    openmoji: true,
    animals: true,
    nature: true,
    science: true,
    // Extended packs — opt-in so startup stays fast.
    "material-outlined": false,
    "material-sharp": false,
    "phosphor-bold": false,
    "phosphor-fill": false,
    "phosphor-light": false,
    "phosphor-thin": false,
    "phosphor-duotone": false,
    "unicons-solid": false,
    "unicons-monochrome": false,
    "unicons-thinline": false,
    "boxicons-solid": false,
    "boxicons-logos": false,
    "heroicons-solid": false,
    "openmoji-black": false,
    fontawesome: false,
    "simple-icons": false,
    ionicons: false,
    antd: false,
    "line-awesome": false,
    eva: false,
    octicons: false,
    cssgg: false,
    twemoji: false,
    fluent: false
  },
  overrides: {},
  rules: [],
  fileTypeDefaults: {},
  defaultIcon: null,
  favoriteIconIds: [],
  collections: [],
  iconTags: {},
  recentIconIds: [],
  userIcons: [],
  lastPackFilter: "all",
  iconGridDensity: "comfortable",
  reportUrl: DEFAULT_REPORT_URL
};
var PACK_LABELS = {
  lucide: "Lucide",
  material: "Material Symbols",
  "material-outlined": "Material Outlined",
  "material-sharp": "Material Sharp",
  star: "Star Icons",
  tabler: "Tabler",
  "tabler-filled": "Tabler Filled",
  unicons: "Unicons",
  "unicons-solid": "Unicons Solid",
  "unicons-monochrome": "Unicons Mono",
  "unicons-thinline": "Unicons Thinline",
  remix: "Remix Icon",
  phosphor: "Phosphor",
  "phosphor-bold": "Phosphor Bold",
  "phosphor-fill": "Phosphor Fill",
  "phosphor-light": "Phosphor Light",
  "phosphor-thin": "Phosphor Thin",
  "phosphor-duotone": "Phosphor Duotone",
  bootstrap: "Bootstrap Icons",
  boxicons: "Boxicons",
  "boxicons-solid": "Boxicons Solid",
  "boxicons-logos": "Boxicons Logos",
  heroicons: "Heroicons",
  "heroicons-solid": "Heroicons Solid",
  fontawesome: "Font Awesome",
  "simple-icons": "Simple Icons",
  ionicons: "Ionicons",
  antd: "Ant Design",
  "line-awesome": "Line Awesome",
  eva: "Eva Icons",
  octicons: "Octicons",
  cssgg: "CSS.gg",
  openmoji: "OpenMoji Color",
  "openmoji-black": "OpenMoji Mono",
  twemoji: "Twemoji",
  fluent: "Fluent Emoji",
  animals: "Animals",
  nature: "Nature & Flowers",
  science: "Science",
  user: "My Icons"
};
var PACK_SAMPLE_ICON = {
  star: "star-sparkle",
  lucide: "sparkles",
  material: "home",
  "material-outlined": "home",
  "material-sharp": "home",
  tabler: "layout-grid",
  "tabler-filled": "home",
  unicons: "apps",
  "unicons-solid": "home",
  "unicons-monochrome": "home",
  "unicons-thinline": "home",
  remix: "home-line",
  phosphor: "house",
  "phosphor-bold": "house-bold",
  "phosphor-fill": "house-fill",
  "phosphor-light": "house-light",
  "phosphor-thin": "house-thin",
  "phosphor-duotone": "house-duotone",
  bootstrap: "house",
  boxicons: "home",
  "boxicons-solid": "home",
  "boxicons-logos": "github",
  heroicons: "home",
  "heroicons-solid": "home",
  fontawesome: "house",
  "simple-icons": "github",
  ionicons: "home",
  antd: "home-outlined",
  "line-awesome": "home",
  eva: "home-outline",
  octicons: "home-16",
  cssgg: "home",
  openmoji: "grinning-face",
  "openmoji-black": "grinning-face",
  twemoji: "grinning-face",
  fluent: "smiling-face",
  animals: "dog",
  nature: "rose",
  science: "microscope"
};
var PACK_GROUPS = [
  {
    title: "Essentials \xB7 on by default",
    open: true,
    packs: [
      "lucide",
      "material",
      "star",
      "tabler",
      "tabler-filled",
      "unicons",
      "remix",
      "phosphor",
      "bootstrap",
      "boxicons",
      "heroicons",
      "openmoji",
      "animals",
      "nature",
      "science"
    ]
  },
  {
    title: "More icon sets",
    open: true,
    packs: [
      "fontawesome",
      "simple-icons",
      "ionicons",
      "antd",
      "line-awesome",
      "eva",
      "octicons",
      "cssgg",
      "twemoji",
      "fluent"
    ]
  },
  {
    title: "Weights & variants",
    open: false,
    packs: [
      "material-outlined",
      "material-sharp",
      "phosphor-bold",
      "phosphor-fill",
      "phosphor-light",
      "phosphor-thin",
      "phosphor-duotone",
      "unicons-solid",
      "unicons-monochrome",
      "unicons-thinline",
      "boxicons-solid",
      "boxicons-logos",
      "heroicons-solid",
      "openmoji-black"
    ]
  }
];
var CONDITION_LABELS = {
  filename: "File name",
  path: "File path",
  extension: "Extension",
  folder: "Folder",
  tag: "Tag",
  property: "Property",
  heading: "Heading",
  time: "Time"
};
var OP_LABELS = {
  equals: "is equal to",
  contains: "contains",
  startsWith: "starts with",
  endsWith: "ends with",
  matches: "matches regex",
  isIn: "is in",
  isNotIn: "is not in",
  exists: "exists",
  notExists: "does not exist"
};

// src/data/icons.ts
function strokeShell(inner, viewBox = "0 0 24 24") {
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${viewBox}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${inner}</svg>`;
}
function fillShell(inner, viewBox) {
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${viewBox}" fill="currentColor">${inner}</svg>`;
}
function emojiShell(emoji) {
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><text x="12" y="12" font-size="19" text-anchor="middle" dominant-baseline="central">${emoji}</text></svg>`;
}
function plainShell(inner, viewBox) {
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${viewBox}">${inner}</svg>`;
}
function iconId(pack, name) {
  return `si-${pack}-${name}`;
}
function buildPack(pack, raws, shell) {
  return raws.map((r) => {
    const tags = [...r.tags ?? [], ...r.name.split(/[-_]/)].filter(Boolean);
    return {
      id: iconId(pack, r.name),
      pack,
      name: r.name,
      tags: Array.from(new Set(tags)),
      svg: shell(r.svg, r.viewBox)
    };
  });
}
function buildEmojiPack(pack, entries) {
  return entries.map((e) => ({
    id: iconId(pack, e.name),
    pack,
    name: e.name,
    tags: Array.from(/* @__PURE__ */ new Set([...e.tags, ...e.name.split(/[-_]/)])),
    svg: emojiShell(e.emoji)
  }));
}
var STAR_ICONS_FULL = buildPack("star", STAR_ICONS, strokeShell);
var ANIMALS_ICONS2 = buildEmojiPack("animals", EMOJI_PACKS.animals);
var NATURE_ICONS2 = buildEmojiPack("nature", EMOJI_PACKS.nature);
var SCIENCE_ICONS2 = buildEmojiPack("science", EMOJI_PACKS.science);
var CORE_PACKS = ["star", "animals", "nature", "science"];
var EXTERNAL_PACKS = ALL_PACKS.filter((p) => !CORE_PACKS.includes(p));
var ALL_ICONS = [
  ...STAR_ICONS_FULL,
  ...ANIMALS_ICONS2,
  ...NATURE_ICONS2,
  ...SCIENCE_ICONS2
];
var ICONS_BY_PACK = {
  star: STAR_ICONS_FULL,
  animals: ANIMALS_ICONS2,
  nature: NATURE_ICONS2,
  science: SCIENCE_ICONS2
};
var ICON_INDEX = new Map(
  ALL_ICONS.map((i) => [i.id, i])
);
function getIcon(id) {
  if (!id) return void 0;
  return ICON_INDEX.get(id);
}
var PACK_VERSIONS = {
  star: "1.0.0",
  animals: "system emoji",
  nature: "system emoji",
  science: "system emoji"
};
var SHELL_BY_PACK = {
  // stroke-based
  lucide: strokeShell,
  tabler: strokeShell,
  heroicons: strokeShell,
  cssgg: strokeShell,
  // fill-based
  "tabler-filled": fillShell,
  material: fillShell,
  "material-outlined": fillShell,
  "material-sharp": fillShell,
  unicons: fillShell,
  "unicons-solid": fillShell,
  "unicons-monochrome": fillShell,
  "unicons-thinline": fillShell,
  remix: fillShell,
  phosphor: fillShell,
  "phosphor-bold": fillShell,
  "phosphor-fill": fillShell,
  "phosphor-light": fillShell,
  "phosphor-thin": fillShell,
  "phosphor-duotone": fillShell,
  bootstrap: fillShell,
  boxicons: fillShell,
  "boxicons-solid": fillShell,
  "boxicons-logos": fillShell,
  "heroicons-solid": fillShell,
  fontawesome: fillShell,
  "simple-icons": fillShell,
  antd: fillShell,
  "line-awesome": fillShell,
  eva: fillShell,
  octicons: fillShell,
  // self-contained (own colors / mixed fill+stroke)
  ionicons: plainShell,
  openmoji: plainShell,
  "openmoji-black": plainShell,
  twemoji: plainShell,
  fluent: plainShell
};
function buildPackFromRaw(pack, raw) {
  const shell = SHELL_BY_PACK[pack] ?? plainShell;
  return buildPack(pack, raw.icons ?? [], shell);
}
function mountPack(pack, defs) {
  ICONS_BY_PACK[pack] = defs;
  for (const d of defs) ICON_INDEX.set(d.id, d);
  ALL_ICONS = [...ALL_ICONS, ...defs];
}
function unmountPack(pack) {
  const defs = ICONS_BY_PACK[pack];
  if (!defs) return;
  for (const d of defs) ICON_INDEX.delete(d.id);
  ALL_ICONS = ALL_ICONS.filter((i) => i.pack !== pack);
  delete ICONS_BY_PACK[pack];
}
function isCorePack(pack) {
  return CORE_PACKS.includes(pack);
}
function isPackMounted(pack) {
  return !!ICONS_BY_PACK[pack];
}
function buildUserIconDefs(icons) {
  return icons.map((u) => ({
    id: iconId("user", u.name),
    pack: "user",
    name: u.name,
    tags: Array.from(/* @__PURE__ */ new Set(["user", ...u.tags ?? [], ...u.name.split(/[-_]/)])),
    svg: u.svg
  }));
}
function mountUserPack(defs) {
  unmountPack("user");
  if (defs.length) mountPack("user", defs);
}

// src/core/ruleEngine.ts
var import_obsidian = require("obsidian");

// src/utils.ts
var uidCounter = 0;
function uid(prefix = "id") {
  uidCounter += 1;
  return `${prefix}-${Date.now().toString(36)}-${uidCounter.toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
}
function hashString(str) {
  let h = 5381;
  for (let i = 0; i < str.length; i++) {
    h = h * 33 ^ str.charCodeAt(i);
  }
  return h >>> 0;
}
function stableIndex(key, n) {
  if (n <= 0) return 0;
  return hashString(key) % n;
}
function debounce(fn, ms) {
  let t = null;
  return (...args) => {
    if (t !== null) window.clearTimeout(t);
    t = window.setTimeout(() => {
      t = null;
      fn(...args);
    }, ms);
  };
}
function fuzzyScore(query, text) {
  const q = query.toLowerCase();
  const t = text.toLowerCase();
  if (!q) return 1;
  if (t.includes(q)) return 100 + (t.length - q.length) * -1;
  let qi = 0;
  let score = 0;
  let streak = 0;
  for (let ti = 0; ti < t.length && qi < q.length; ti++) {
    if (t[ti] === q[qi]) {
      qi++;
      streak++;
      score += 2 + streak;
    } else {
      streak = 0;
      score -= 1;
    }
  }
  return qi === q.length ? Math.max(1, score) : 0;
}
function searchIcons(icons, query, limit = 200) {
  const q = query.trim();
  if (!q) return icons.slice(0, limit);
  const scored = [];
  for (const icon of icons) {
    const nameScore = fuzzyScore(q, icon.name.replace(/[-_]/g, " "));
    let score;
    if (nameScore > 0) {
      score = nameScore + 1e4;
    } else {
      score = 0;
      for (const tag of icon.tags) {
        const s = fuzzyScore(q, tag);
        if (s > score) score = s;
      }
    }
    if (score > 0) scored.push({ icon, score });
  }
  scored.sort((a, b) => b.score - a.score || a.icon.name.localeCompare(b.icon.name));
  return scored.slice(0, limit).map((s) => s.icon);
}
function downloadJson(filename, data) {
  const blob = new Blob([JSON.stringify(data, null, 2)], {
    type: "application/json"
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  window.setTimeout(() => URL.revokeObjectURL(url), 2e3);
}
function parseMinutes(value) {
  if (!value) return null;
  const m = /^(\d{1,2}):(\d{2})$/.exec(value.trim());
  if (!m) return null;
  const h = parseInt(m[1], 10);
  const min = parseInt(m[2], 10);
  if (h > 23 || min > 59) return null;
  return h * 60 + min;
}
function toMinutes(date) {
  return date.getHours() * 60 + date.getMinutes();
}
function isValidRegex(value) {
  try {
    new RegExp(value);
    return true;
  } catch {
    return false;
  }
}
function clamp(n, min, max) {
  return Math.min(max, Math.max(min, n));
}
function normalizeExt(ext) {
  return ext.trim().toLowerCase().replace(/^\./, "");
}
function slugifyName(s) {
  return s.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
}
function ensureSvg(text) {
  const t = text.trim();
  if (/<svg[\s>]/i.test(t)) return t;
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">${t}</svg>`;
}
function svgForClipboard(svg, size = 24) {
  if (/\swidth=|\sheight=/i.test(svg)) return svg;
  return svg.replace(/^<svg/i, `<svg width="${size}" height="${size}"`);
}

// src/core/ruleEngine.ts
function buildFileContext(file, app, now = /* @__PURE__ */ new Date()) {
  const isFolder = file instanceof import_obsidian.TFolder;
  const name = file.name;
  const extension = isFolder ? "" : file.extension.toLowerCase();
  const basename = isFolder ? name : extension ? name.slice(0, -(extension.length + 1)) : name;
  const folderPath = file.parent ? file.parent.path : "/";
  let tags = [];
  let properties = {};
  let headings = [];
  if (!isFolder && app.metadataCache) {
    const cache = app.metadataCache.getFileCache(file);
    if (cache) {
      if (cache.tags) tags = cache.tags.map((t) => t.tag.replace(/^#/, ""));
      if (cache.frontmatter) {
        properties = { ...cache.frontmatter };
        const ft = cache.frontmatter.tags;
        if (Array.isArray(ft)) tags = tags.concat(ft.map(String));
        else if (typeof ft === "string") tags.push(ft);
      }
      if (cache.headings) headings = cache.headings.map((h) => h.heading);
    }
  }
  return { path: file.path, basename, name, extension, isFolder, folderPath, tags, properties, headings, now };
}
function stringOp(value, op, target) {
  switch (op) {
    case "equals":
      return value === target;
    case "contains":
      return value.includes(target);
    case "startsWith":
      return value.startsWith(target);
    case "endsWith":
      return value.endsWith(target);
    case "matches":
      return isValidRegex(target) && new RegExp(target).test(value);
    case "isIn": {
      return target.split(",").map((x) => x.trim()).filter(Boolean).includes(value);
    }
    case "isNotIn": {
      return !target.split(",").map((x) => x.trim()).filter(Boolean).includes(value);
    }
    default:
      return false;
  }
}
function anyOp(values, op, target) {
  if (values.length === 0) return op === "notExists";
  return values.some((v) => stringOp(v, op, target));
}
function evaluateCondition(cond, ctx) {
  const v = cond.value?.trim() ?? "";
  switch (cond.type) {
    case "filename":
      return stringOp(ctx.basename, cond.op, v);
    case "path":
      return stringOp(ctx.path, cond.op, v);
    case "extension":
      return stringOp(ctx.extension, cond.op, v);
    case "folder": {
      const folder = ctx.isFolder ? ctx.path : ctx.folderPath;
      const root = v.replace(/[\\/]+$/, "");
      switch (cond.op) {
        case "isIn":
          return root === "/" || folder === root || folder.startsWith(root + "/");
        case "isNotIn":
          return !(root === "/" || folder === root || folder.startsWith(root + "/"));
        case "contains":
          return folder.includes(v);
        case "matches":
          return isValidRegex(v) && new RegExp(v).test(folder);
        default:
          return stringOp(folder, cond.op, v);
      }
    }
    case "tag": {
      const tags = ctx.tags.map((t) => t.replace(/^#/, "").toLowerCase());
      const target = v.replace(/^#/, "").toLowerCase();
      switch (cond.op) {
        case "equals":
          return tags.includes(target);
        case "contains":
          return tags.some((t) => t.includes(target));
        case "startsWith":
          return tags.some((t) => t.startsWith(target));
        default:
          return anyOp(tags, cond.op, target);
      }
    }
    case "property": {
      const key = cond.key?.trim() ?? "";
      if (!key) return false;
      const has = Object.prototype.hasOwnProperty.call(ctx.properties, key);
      switch (cond.op) {
        case "exists":
          return has;
        case "notExists":
          return !has;
        case "equals":
          return has && String(ctx.properties[key]) === v;
        case "contains":
          return has && String(ctx.properties[key]).includes(v);
        default:
          return has && stringOp(String(ctx.properties[key]), cond.op, v);
      }
    }
    case "heading":
      return anyOp(ctx.headings, cond.op, v);
    case "time":
      return timeOp(cond, ctx.now);
    default:
      return false;
  }
}
function timeOp(cond, now) {
  if (cond.days?.length && !cond.days.includes(now.getDay())) return false;
  const m = toMinutes(now);
  const from = parseMinutes(cond.from);
  const to = parseMinutes(cond.to);
  if (from !== null && to !== null) {
    return from <= to ? m >= from && m <= to : m >= from || m <= to;
  }
  if (from !== null) return m >= from;
  if (to !== null) return m <= to;
  return true;
}
function matchRule(rule, ctx) {
  if (rule.conditions.length === 0) return true;
  const results = rule.conditions.map((c) => evaluateCondition(c, ctx));
  return rule.match === "all" ? results.every(Boolean) : results.some(Boolean);
}
function resolveIcon(settings, ctx) {
  const override = settings.overrides[ctx.path];
  if (override) {
    return valid(settings, override) ? { iconId: override, source: "override", detail: "Manual override" } : { iconId: null, source: "override", detail: "Manual override (icon unavailable)" };
  }
  for (const rule of settings.rules) {
    if (!rule.enabled) continue;
    if (!matchRule(rule, ctx)) continue;
    const action = rule.action;
    if (action.type === "icon") {
      return valid(settings, action.iconId) ? { iconId: action.iconId, source: "rule", detail: rule.name, ruleId: rule.id } : { iconId: null, source: "rule", detail: `${rule.name} (icon unavailable)`, ruleId: rule.id };
    }
    if (action.type === "clear") {
      return { iconId: null, source: "rule", detail: rule.name, ruleId: rule.id };
    }
    if (action.type === "random") {
      const col = settings.collections.find((c) => c.id === action.collectionId);
      const ids = col?.iconIds ?? [];
      if (ids.length) {
        const id = ids[stableIndex(`${ctx.path}:${rule.id}`, ids.length)];
        return {
          iconId: id,
          source: "rule",
          detail: `${rule.name} (random from "${col?.name ?? "collection"}")`,
          ruleId: rule.id
        };
      }
      continue;
    }
  }
  if (!ctx.isFolder) {
    const ft = settings.fileTypeDefaults[ctx.extension];
    if (ft && valid(settings, ft)) {
      return { iconId: ft, source: "filetype", detail: `File type .${ctx.extension}` };
    }
  }
  if (settings.defaultIcon) {
    return valid(settings, settings.defaultIcon) ? { iconId: settings.defaultIcon, source: "default", detail: "Default icon" } : { iconId: null, source: "default", detail: "Default icon (unavailable)" };
  }
  return { iconId: null, source: "none", detail: "Obsidian default" };
}
function valid(settings, iconId2) {
  const def = getIcon(iconId2);
  if (!def) return false;
  return settings.enabledPacks[def.pack] !== false;
}

// src/core/applier.ts
var IconApplier = class {
  constructor(plugin, app) {
    this.plugin = plugin;
    this.app = app;
    this.patchedViews = /* @__PURE__ */ new Set();
    this.leafProtoPatched = false;
    this.originalUpdateHeaderIcon = null;
  }
  /* --- public ---------------------------------------------------------- */
  /** Re-apply icons everywhere. Cheap; safe to call often. */
  refreshAll() {
    if (this.plugin.settings.fileExplorerIcons) this.patchExplorers();
    else this.unpatchExplorers();
    if (this.plugin.settings.tabIcons) this.patchLeafPrototype();
    this.updateTabs();
    this.updateInlineTitle();
  }
  /** Remove every patch/injection (plugin unload). */
  dispose() {
    this.unpatchExplorers();
    if (this.originalUpdateHeaderIcon && this.leafProtoPatched) {
      import_obsidian2.WorkspaceLeaf.prototype.updateHeaderIcon = this.originalUpdateHeaderIcon;
      this.leafProtoPatched = false;
    }
    for (const leaf of this.app.workspace.getLeavesOfType("markdown")) {
      leaf.view.contentEl.querySelectorAll(".si-inline-icon").forEach((el) => el.remove());
    }
    this.updateTabs();
  }
  /** Resolve the icon for a file/folder (used by menus & status bar too). */
  resolve(file) {
    if (!file) return { iconId: null, source: "none", detail: "No file" };
    const ctx = buildFileContext(file, this.app);
    return resolveIcon(this.plugin.settings, ctx);
  }
  /* --- file explorer ---------------------------------------------------- */
  patchExplorers() {
    for (const leaf of this.app.workspace.getLeavesOfType("file-explorer")) {
      const view = leaf.view;
      if (!view || this.patchedViews.has(view)) continue;
      this.patchedViews.add(view);
      const origGetIcon = view.getIcon;
      const origGetFolderIcon = view.getFolderIcon;
      const origIsIconVisible = view.isIconVisible;
      view.__siOriginals = {
        getIcon: origGetIcon,
        getFolderIcon: origGetFolderIcon,
        isIconVisible: origIsIconVisible
      };
      view.getIcon = (file) => {
        const res = this.resolve(file);
        return res.iconId ?? (origGetIcon ? origGetIcon(file) : void 0);
      };
      if (typeof view.getFolderIcon === "function") {
        view.getFolderIcon = (folder) => {
          const res = this.resolve(folder);
          return res.iconId ?? (origGetFolderIcon ? origGetFolderIcon(folder) : void 0);
        };
      }
      view.isIconVisible = () => true;
      void origIsIconVisible;
    }
    this.refreshExplorerDom();
  }
  unpatchExplorers() {
    for (const view of this.patchedViews) {
      if (!view) continue;
      const saved = view.__siOriginals;
      if (saved) {
        if (saved.getIcon !== void 0) view.getIcon = saved.getIcon;
        if (saved.getFolderIcon !== void 0)
          view.getFolderIcon = saved.getFolderIcon;
        if (saved.isIconVisible !== void 0)
          view.isIconVisible = saved.isIconVisible;
      }
    }
    this.patchedViews.clear();
  }
  /** Directly refresh the DOM icons so changes show instantly. */
  refreshExplorerDom() {
    if (!this.plugin.settings.fileExplorerIcons) return;
    const showTooltips = this.plugin.settings.showSourceTooltips;
    for (const leaf of this.app.workspace.getLeavesOfType("file-explorer")) {
      const view = leaf.view;
      const items = view.fileItems;
      if (!items) continue;
      for (const key of Object.keys(items)) {
        const item = items[key];
        const file = item?.file;
        if (!file) continue;
        const iconEl = item.selfEl?.querySelector(".tree-item-icon");
        if (!iconEl) continue;
        const res = this.resolve(file);
        if (res.iconId) {
          try {
            (0, import_obsidian2.setIcon)(iconEl, res.iconId);
          } catch {
          }
        }
        if (showTooltips && item.selfEl) {
          const label = res.iconId ? prettyIconName(res.iconId) : "Default icon";
          item.selfEl.title = `${label} \u2014 ${res.detail}`;
        } else if (item.selfEl) {
          item.selfEl.title = "";
        }
      }
    }
  }
  /* --- tabs -------------------------------------------------------------- */
  patchLeafPrototype() {
    if (this.leafProtoPatched) return;
    const proto = import_obsidian2.WorkspaceLeaf.prototype;
    const updateHeaderIcon = proto.updateHeaderIcon;
    if (typeof updateHeaderIcon !== "function") return;
    this.leafProtoPatched = true;
    this.originalUpdateHeaderIcon = updateHeaderIcon;
    const self = this;
    proto.updateHeaderIcon = function() {
      const result = updateHeaderIcon.call(this);
      try {
        self.applyToLeaf(this);
      } catch {
      }
      return result;
    };
  }
  applyToLeaf(leaf) {
    if (!this.plugin.settings.tabIcons) return;
    const view = leaf.view;
    if (!view) return;
    const file = view.file;
    if (!(file instanceof import_obsidian2.TFile) && !(file instanceof import_obsidian2.TFolder)) return;
    const iconEl = leaf.tabHeaderInnerIconEl;
    if (!iconEl) return;
    const res = this.resolve(file);
    if (res.iconId) {
      try {
        (0, import_obsidian2.setIcon)(iconEl, res.iconId);
      } catch {
      }
      if (this.plugin.settings.showSourceTooltips) {
        iconEl.title = `${prettyIconName(res.iconId)} \u2014 ${res.detail}`;
      }
    }
  }
  updateTabs() {
    const workspace = this.app.workspace;
    const leaves = typeof workspace.getLeaves === "function" ? workspace.getLeaves() : this.app.workspace.getLeavesOfType("markdown");
    for (const leaf of leaves) {
      if (!this.plugin.settings.tabIcons) {
        continue;
      }
      this.applyToLeaf(leaf);
    }
  }
  /* --- inline title ------------------------------------------------------ */
  updateInlineTitle() {
    const view = this.app.workspace.getActiveViewOfType(import_obsidian2.MarkdownView);
    if (!view || !view.file) return;
    for (const leaf of this.app.workspace.getLeavesOfType("markdown")) {
      const other = leaf.view;
      if (other !== view) {
        other.contentEl.querySelectorAll(".si-inline-icon").forEach((el) => el.remove());
      }
    }
    const titleEl = view.contentEl.querySelector(".inline-title");
    if (!titleEl) return;
    const inSource = view.getMode() === "source";
    const enabled = this.plugin.settings.inlineTitleIcons && (!inSource || this.plugin.settings.inlineTitleEditMode);
    let iconEl = titleEl.querySelector(":scope > .si-inline-icon");
    if (!enabled) {
      iconEl?.remove();
      return;
    }
    const res = this.resolve(view.file);
    if (!res.iconId) {
      iconEl?.remove();
      return;
    }
    if (!iconEl) {
      iconEl = titleEl.createEl("span", { cls: "si-inline-icon" });
      iconEl.setAttribute("contenteditable", "false");
      titleEl.prepend(iconEl);
    }
    try {
      (0, import_obsidian2.setIcon)(iconEl, res.iconId);
    } catch {
    }
    if (this.plugin.settings.showSourceTooltips) {
      iconEl.title = `${prettyIconName(res.iconId)} \u2014 ${res.detail}`;
    }
  }
};
function prettyIconName(id) {
  const def = getIcon(id);
  if (!def) return id;
  return `${def.pack} \xB7 ${def.name}`;
}

// src/core/iconStore.ts
var import_obsidian3 = require("obsidian");
var IconStore = class {
  constructor(app, getPluginManifest, getSettingsFn, save) {
    this.app = app;
    this.getPluginManifest = getPluginManifest;
    this.getSettingsFn = getSettingsFn;
    this.save = save;
    this.listeners = /* @__PURE__ */ new Set();
    this.manifest = { packs: {} };
    this.pending = /* @__PURE__ */ new Map();
  }
  /* --- lifecycle -------------------------------------------------------- */
  /** Register every currently mounted icon with Obsidian's global registry. */
  registerIcons() {
    for (const icon of ALL_ICONS) {
      try {
        (0, import_obsidian3.addIcon)(icon.id, icon.svg);
      } catch {
      }
    }
  }
  subscribe(fn) {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }
  /** Re-render open views (called after settings/library changes). */
  notify() {
    for (const fn of this.listeners) fn();
  }
  async mutate(fn) {
    fn(this.getSettingsFn());
    await this.save();
    this.notify();
  }
  /* --- pack loading ------------------------------------------------------ */
  packDataPath(file) {
    return (0, import_obsidian3.normalizePath)(
      `${this.app.vault.configDir}/plugins/${this.getPluginManifest().id}/packs/${file}`
    );
  }
  async readPackFile(file) {
    const text = await this.app.vault.adapter.read(this.packDataPath(file));
    return JSON.parse(text);
  }
  /** Load packs/manifest.json (versions + counts, no icon data). */
  async loadManifest() {
    try {
      this.manifest = await this.readPackFile("manifest.json");
    } catch (err) {
      console.warn("[Star Icons] could not read packs/manifest.json", err);
      this.manifest = { packs: {} };
    }
    this.notify();
  }
  /** Load and register one external pack (idempotent, awaitable). */
  loadPack(pack) {
    if (isCorePack(pack) || isPackMounted(pack)) return Promise.resolve();
    const inFlight = this.pending.get(pack);
    if (inFlight) return inFlight;
    const promise = (async () => {
      try {
        const raw = await this.readPackFile(`${pack}.json`);
        const defs = buildPackFromRaw(pack, raw);
        for (const d of defs) {
          try {
            (0, import_obsidian3.addIcon)(d.id, d.svg);
          } catch {
          }
        }
        mountPack(pack, defs);
      } catch (err) {
        console.warn(`[Star Icons] failed to load pack "${pack}"`, err);
      } finally {
        this.pending.delete(pack);
        this.notify();
      }
    })();
    this.pending.set(pack, promise);
    return promise;
  }
  /** Load every enabled external pack (fired at startup, non-blocking). */
  loadEnabledPacks() {
    const s = this.getSettingsFn();
    const enabled = EXTERNAL_PACKS.filter((p) => s.enabledPacks[p] !== false);
    return Promise.allSettled(enabled.map((p) => this.loadPack(p))).then(() => void 0);
  }
  /** Enable a pack in settings and load it immediately (used by the UI). */
  async enablePack(pack) {
    const s = this.getSettingsFn();
    if (s.enabledPacks[pack] === true && isPackMounted(pack)) return;
    s.enabledPacks[pack] = true;
    await this.save();
    await this.loadPack(pack);
    this.notify();
  }
  /** Disable a pack (icons stay cached, so re-enabling is instant). */
  async disablePack(pack) {
    const s = this.getSettingsFn();
    if (s.enabledPacks[pack] === false) return;
    s.enabledPacks[pack] = false;
    await this.save();
    this.notify();
  }
  /* --- pack info ---------------------------------------------------------- */
  getPackInfo(pack) {
    return this.manifest.packs[pack] ?? { version: "?", count: 0 };
  }
  getPackCount(pack) {
    if (isCorePack(pack)) return ICONS_BY_PACK[pack]?.length ?? 0;
    return this.manifest.packs[pack]?.count ?? ICONS_BY_PACK[pack]?.length ?? 0;
  }
  getPackVersion(pack) {
    if (isCorePack(pack)) return PACK_VERSIONS[pack] ?? "1.0.0";
    return this.manifest.packs[pack]?.version ?? "?";
  }
  /** Total icons across enabled packs (from the manifest; no pack loading). */
  totalCount() {
    const s = this.getSettingsFn();
    const sum = ALL_PACKS.reduce(
      (acc, p) => acc + (s.enabledPacks[p] !== false ? this.getPackCount(p) : 0),
      0
    );
    return sum + s.userIcons.length;
  }
  isPackLoaded(pack) {
    return isPackMounted(pack);
  }
  isPackLoading(pack) {
    return this.pending.has(pack);
  }
  /* --- query --- */
  /** Live settings access (read-only use; mutations go through mutate()). */
  getSettings() {
    return this.getSettingsFn();
  }
  packEnabled(pack) {
    return this.getSettingsFn().enabledPacks[pack] !== false;
  }
  availableIcons() {
    const s = this.getSettingsFn();
    return ALL_ICONS.filter((i) => s.enabledPacks[i.pack] !== false);
  }
  search(query, packFilter = "all", limit = 300) {
    let icons = this.availableIcons();
    if (packFilter !== "all") icons = icons.filter((i) => i.pack === packFilter);
    return searchIcons(icons, query, limit);
  }
  /* --- user icons ("My Icons" pack) --------------------------------------- */
  userIcons() {
    return this.getSettingsFn().userIcons;
  }
  /** Register + mount the user icons from settings (called at startup). */
  mountUserIcons() {
    const defs = buildUserIconDefs(this.userIcons());
    for (const d of defs) {
      try {
        (0, import_obsidian3.addIcon)(d.id, d.svg);
      } catch {
      }
    }
    mountUserPack(defs);
  }
  /** Import one or more user SVGs; returns how many were added. */
  async addUserIcons(entries) {
    if (!entries.length) return 0;
    let added = 0;
    await this.mutate((s) => {
      const existing = new Set(s.userIcons.map((u) => u.name));
      for (const e of entries) {
        let name = slugifyName(e.name);
        if (!name) name = "icon";
        let candidate = name;
        let n = 2;
        while (existing.has(candidate)) candidate = `${name}-${n++}`;
        existing.add(candidate);
        s.userIcons.push({ name: candidate, svg: ensureSvg(e.svg) });
        added++;
      }
    });
    this.mountUserIcons();
    return added;
  }
  /** Delete one user icon by its icon id ("si-user-<name>"). */
  async removeUserIcon(id) {
    const name = id.replace(/^si-user-/, "");
    await this.mutate((s) => {
      s.userIcons = s.userIcons.filter((u) => u.name !== name);
    });
    this.mountUserIcons();
  }
  /* --- favorites --- */
  isFavorite(id) {
    return this.getSettingsFn().favoriteIconIds.includes(id);
  }
  async toggleFavorite(id) {
    await this.mutate((s) => {
      const i = s.favoriteIconIds.indexOf(id);
      if (i >= 0) s.favoriteIconIds.splice(i, 1);
      else s.favoriteIconIds.unshift(id);
    });
  }
  favoriteIcons() {
    return this.getSettings().favoriteIconIds.map(getIcon).filter((i) => !!i);
  }
  /* --- recents --- */
  async pushRecent(id) {
    await this.mutate((s) => {
      s.recentIconIds = [id, ...s.recentIconIds.filter((x) => x !== id)].slice(0, 48);
    });
  }
  recentIcons() {
    return this.getSettings().recentIconIds.map(getIcon).filter((i) => !!i);
  }
  /* --- collections --- */
  createCollection(name) {
    const col = {
      id: uid("col"),
      name,
      iconIds: [],
      createdAt: Date.now()
    };
    return this.mutate((s) => s.collections.push(col)).then(() => col);
  }
  async renameCollection(id, name) {
    await this.mutate((s) => {
      const c = s.collections.find((x) => x.id === id);
      if (c) c.name = name;
    });
  }
  async deleteCollection(id) {
    await this.mutate((s) => {
      s.collections = s.collections.filter((c) => c.id !== id);
      for (const rule of s.rules) {
        if (rule.action.type === "random" && rule.action.collectionId === id) {
          rule.action = { type: "clear" };
        }
      }
    });
  }
  async addToCollection(collectionId, iconId2) {
    await this.mutate((s) => {
      const c = s.collections.find((x) => x.id === collectionId);
      if (c && !c.iconIds.includes(iconId2)) c.iconIds.push(iconId2);
    });
  }
  async removeFromCollection(collectionId, iconId2) {
    await this.mutate((s) => {
      const c = s.collections.find((x) => x.id === collectionId);
      if (c) c.iconIds = c.iconIds.filter((i) => i !== iconId2);
    });
  }
  async moveInCollection(collectionId, from, to) {
    await this.mutate((s) => {
      const c = s.collections.find((x) => x.id === collectionId);
      if (!c || from < 0 || from >= c.iconIds.length) return;
      const [item] = c.iconIds.splice(from, 1);
      const clamped = Math.max(0, Math.min(to, c.iconIds.length));
      c.iconIds.splice(clamped, 0, item);
    });
  }
  collectionsContaining(iconId2) {
    return this.getSettings().collections.filter((c) => c.iconIds.includes(iconId2));
  }
  /* --- tags --- */
  userTagsFor(iconId2) {
    return this.getSettings().iconTags[iconId2] ?? [];
  }
  allUserTags() {
    const set = /* @__PURE__ */ new Set();
    for (const tags of Object.values(this.getSettings().iconTags)) {
      for (const t of tags) set.add(t);
    }
    return Array.from(set).sort();
  }
  async addUserTag(iconId2, tag) {
    const t = tag.trim().toLowerCase().replace(/\s+/g, "-");
    if (!t) return;
    await this.mutate((s) => {
      s.iconTags[iconId2] = s.iconTags[iconId2] ?? [];
      if (!s.iconTags[iconId2].includes(t)) s.iconTags[iconId2].push(t);
    });
  }
  async removeUserTag(iconId2, tag) {
    await this.mutate((s) => {
      s.iconTags[iconId2] = (s.iconTags[iconId2] ?? []).filter((t) => t !== tag);
    });
  }
  async renameUserTag(oldTag, newTag) {
    const t = newTag.trim().toLowerCase().replace(/\s+/g, "-");
    if (!t || t === oldTag) return;
    await this.mutate((s) => {
      for (const key of Object.keys(s.iconTags)) {
        s.iconTags[key] = s.iconTags[key].map((x) => x === oldTag ? t : x);
      }
    });
  }
  /** Delete a user tag from every icon that has it. */
  async deleteUserTag(tag) {
    await this.mutate((s) => {
      for (const key of Object.keys(s.iconTags)) {
        s.iconTags[key] = s.iconTags[key].filter((t) => t !== tag);
      }
    });
  }
  /** Remove every user tag from every icon. */
  async clearAllUserTags() {
    await this.mutate((s) => {
      s.iconTags = {};
    });
  }
};

// src/ui/components.ts
var import_obsidian4 = require("obsidian");
function brandIconId() {
  try {
    return (0, import_obsidian4.getIcon)("si-star-sparkle") ? "si-star-sparkle" : "star";
  } catch {
    return "star";
  }
}
function renderIcon(el, iconId2, size) {
  try {
    (0, import_obsidian4.setIcon)(el, iconId2);
  } catch {
    el.empty();
    return;
  }
  const svg = el.querySelector("svg");
  if (svg && size) {
    svg.setAttribute("width", String(size));
    svg.setAttribute("height", String(size));
  }
}
function fitPopoverToPane(popover, btn, manager, maxWidth = 300, minWidth = 180) {
  const mr = manager.getBoundingClientRect();
  const br = btn.getBoundingClientRect();
  const spaceRight = mr.right - br.left;
  const spaceLeft = br.right - mr.left;
  let width = Math.min(maxWidth, Math.max(minWidth, manager.clientWidth - 24));
  if (spaceRight >= width) {
    popover.style.maxWidth = `${width}px`;
    popover.style.left = "0";
    popover.style.right = "auto";
  } else if (spaceLeft >= width) {
    popover.style.maxWidth = `${width}px`;
    popover.style.left = "auto";
    popover.style.right = "0";
  } else {
    width = Math.max(120, Math.max(spaceLeft, spaceRight) - 8);
    popover.style.maxWidth = `${width}px`;
    if (spaceLeft >= spaceRight) {
      popover.style.left = "auto";
      popover.style.right = "0";
    } else {
      popover.style.left = "0";
      popover.style.right = "auto";
    }
  }
}
function emptyState(text, hint = "") {
  const el = document.createElement("div");
  el.className = "si-empty";
  el.createEl("div", { cls: "si-empty-icon" }).textContent = "\u2726";
  el.createEl("div", { cls: "si-empty-text", text });
  if (hint) el.createEl("div", { cls: "si-empty-hint", text: hint });
  return el;
}
function iconTile(icon, opts = {}) {
  const btn = document.createElement("button");
  btn.className = "si-tile" + (opts.selected ? " is-selected" : "");
  btn.setAttribute("data-icon-id", icon.id);
  btn.type = "button";
  const iconWrap = btn.createDiv({ cls: "si-tile-icon" });
  renderIcon(iconWrap, icon.id);
  btn.createDiv({ cls: "si-tile-name" }).textContent = icon.name;
  if (opts.onPick) btn.addEventListener("click", () => opts.onPick?.(icon));
  if (opts.onStar) {
    const star = btn.createDiv({ cls: "si-tile-star", attr: { "aria-label": "Favorite" } });
    (0, import_obsidian4.setIcon)(star, "star");
    star.addEventListener("click", (ev) => {
      ev.stopPropagation();
      opts.onStar?.(icon, ev);
    });
  }
  if (opts.onContext) {
    btn.addEventListener("contextmenu", (ev) => {
      ev.preventDefault();
      opts.onContext?.(icon, ev);
    });
  }
  return btn;
}
function segmentedControl(options, current, onChange) {
  const wrap = document.createElement("div");
  wrap.className = "si-segmented";
  const buttons = [];
  for (const opt of options) {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "si-seg" + (opt.value === current ? " is-active" : "");
    btn.textContent = opt.label;
    btn.addEventListener("click", () => {
      for (const b of buttons) b.classList.remove("is-active");
      btn.classList.add("is-active");
      onChange(opt.value);
    });
    wrap.appendChild(btn);
    buttons.push(btn);
  }
  return wrap;
}
function makeSortable(listEl, opts) {
  let dragIndex = -1;
  const handleSel = opts.handleSelector ?? ".si-drag-handle";
  const dragClass = opts.dragClass ?? "is-dragging";
  listEl.addEventListener("dragstart", (ev) => {
    const target = ev.target.closest?.("[data-index]");
    if (!target) return;
    if (handleSel) {
      const handle = ev.target.closest?.(handleSel);
      if (!handle) {
        ev.preventDefault();
        return;
      }
    }
    dragIndex = parseInt(target.dataset.index ?? "-1", 10);
    ev.dataTransfer?.setData("text/plain", String(dragIndex));
    if (ev.dataTransfer) ev.dataTransfer.effectAllowed = "move";
    target.classList.add(dragClass);
  });
  listEl.addEventListener("dragover", (ev) => {
    ev.preventDefault();
    const target = ev.target.closest?.("[data-index]");
    if (!target) return;
    const overIndex = parseInt(target.dataset.index ?? "-1", 10);
    if (overIndex === dragIndex) return;
    target.classList.add("is-drag-over");
  });
  listEl.addEventListener("dragleave", (ev) => {
    const target = ev.target.closest?.("[data-index]");
    target?.classList.remove("is-drag-over");
  });
  listEl.addEventListener("drop", (ev) => {
    ev.preventDefault();
    const target = ev.target.closest?.("[data-index]");
    target?.classList.remove("is-drag-over");
    if (dragIndex < 0 || !target) return;
    const to = parseInt(target.dataset.index ?? "-1", 10);
    if (to >= 0 && to !== dragIndex) opts.onReorder(dragIndex, to);
    dragIndex = -1;
  });
  listEl.addEventListener("dragend", () => {
    dragIndex = -1;
    listEl.querySelectorAll(".is-dragging, .is-drag-over").forEach((el) => {
      el.classList.remove("is-dragging", "is-drag-over");
    });
  });
}

// src/ui/promptModal.ts
var import_obsidian5 = require("obsidian");
function promptText(app, opts) {
  return new Promise((resolve) => {
    const modal = new import_obsidian5.Modal(app);
    modal.titleEl.setText(opts.title);
    let value = opts.initial ?? "";
    new import_obsidian5.Setting(modal.contentEl).addText((t) => {
      t.setPlaceholder(opts.placeholder ?? "");
      t.setValue(value);
      t.onChange((v) => value = v);
      window.setTimeout(() => t.inputEl.focus(), 30);
      t.inputEl.addEventListener("keydown", (ev) => {
        if (ev.key === "Enter") {
          ev.preventDefault();
          modal.close();
          resolve(value.trim() || null);
        }
      });
    });
    new import_obsidian5.Setting(modal.contentEl).addButton(
      (b) => b.setButtonText("Cancel").onClick(() => {
        modal.close();
        resolve(null);
      })
    ).addButton(
      (b) => b.setButtonText(opts.okLabel ?? "OK").setCta().onClick(() => {
        modal.close();
        resolve(value.trim() || null);
      })
    );
    modal.open();
  });
}
function confirmDialog(app, opts) {
  return new Promise((resolve) => {
    const modal = new import_obsidian5.Modal(app);
    modal.titleEl.setText(opts.title);
    if (opts.message) {
      modal.contentEl.createDiv({ cls: "setting-item-description", text: opts.message });
    }
    new import_obsidian5.Setting(modal.contentEl).addButton(
      (b) => b.setButtonText("Cancel").onClick(() => {
        modal.close();
        resolve(false);
      })
    ).addButton((b) => {
      const btn = b.setButtonText(opts.confirmLabel ?? "Confirm");
      if (opts.danger) btn.setWarning();
      else btn.setCta();
      btn.onClick(() => {
        modal.close();
        resolve(true);
      });
    });
    modal.open();
  });
}
function promptTextArea(app, opts) {
  return new Promise((resolve) => {
    const modal = new import_obsidian5.Modal(app);
    modal.titleEl.setText(opts.title);
    let value = "";
    const textarea = modal.contentEl.createEl("textarea", {
      cls: "si-textarea",
      attr: { placeholder: opts.placeholder ?? "", spellcheck: "false", rows: "8" }
    });
    textarea.addEventListener("input", () => value = textarea.value);
    textarea.addEventListener("keydown", (ev) => {
      if (ev.key === "Enter" && (ev.ctrlKey || ev.metaKey)) {
        ev.preventDefault();
        modal.close();
        resolve(value.trim() || null);
      }
    });
    window.setTimeout(() => textarea.focus(), 30);
    new import_obsidian5.Setting(modal.contentEl).addButton(
      (b) => b.setButtonText("Cancel").onClick(() => {
        modal.close();
        resolve(null);
      })
    ).addButton(
      (b) => b.setButtonText(opts.okLabel ?? "OK").setCta().onClick(() => {
        modal.close();
        resolve(value.trim() || null);
      })
    );
    modal.open();
  });
}
function promptSize(app, opts = {}) {
  return new Promise((resolve) => {
    const modal = new import_obsidian5.Modal(app);
    modal.titleEl.setText(opts.title ?? "Icon size");
    const presets = opts.presets ?? [16, 24, 32, 48, 64, 96];
    let size = opts.initial ?? 24;
    const chips = modal.contentEl.createDiv({ cls: "si-chips si-size-picker" });
    const buttons = [];
    for (const p of presets) {
      const btn = chips.createEl("button", {
        cls: "si-chip" + (p === size ? " is-active" : ""),
        attr: { type: "button" }
      });
      btn.createSpan({ text: `${p}px` });
      btn.addEventListener("click", () => {
        size = p;
        input.value = String(p);
        buttons.forEach((b) => b.removeClass("is-active"));
        btn.addClass("is-active");
      });
      buttons.push(btn);
    }
    const customRow = modal.contentEl.createDiv({ cls: "si-size-custom" });
    customRow.createSpan({ cls: "si-label", text: "Custom" });
    const input = customRow.createEl("input", {
      cls: "si-text-input",
      attr: { type: "number", min: "1", max: "512", placeholder: "24" }
    });
    input.value = String(size);
    input.addEventListener("keydown", (ev) => {
      if (ev.key === "Enter") {
        ev.preventDefault();
        const v = parseInt(input.value, 10);
        modal.close();
        resolve(!isNaN(v) && v > 0 ? v : null);
      }
    });
    window.setTimeout(() => input.select(), 30);
    new import_obsidian5.Setting(modal.contentEl).addButton(
      (b) => b.setButtonText("Cancel").onClick(() => {
        modal.close();
        resolve(null);
      })
    ).addButton(
      (b) => b.setButtonText("Insert").setCta().onClick(() => {
        const v = parseInt(input.value, 10);
        modal.close();
        resolve(!isNaN(v) && v > 0 ? v : null);
      })
    );
    modal.open();
  });
}

// src/ui/reportBugModal.ts
var import_obsidian6 = require("obsidian");
function obsidianVersion(app) {
  const m = app.manifest;
  return m?.version ?? "unknown";
}
function buildBugReport(ctx) {
  const platform = import_obsidian6.Platform.isMobileApp ? "Mobile" : import_obsidian6.Platform.isDesktopApp ? "Desktop" : "Unknown";
  const os = import_obsidian6.Platform.isMacOS ? "macOS" : import_obsidian6.Platform.isWin ? "Windows" : import_obsidian6.Platform.isLinux ? "Linux" : typeof navigator !== "undefined" ? navigator.platform : "Unknown";
  const lines = [
    "Star Icons \u2014 bug report",
    "=======================",
    "",
    `Plugin version : ${ctx.pluginVersion}`,
    `Obsidian       : ${ctx.appVersion}`,
    `Platform       : ${platform} \xB7 ${os}`,
    `Packs available: ${ctx.packs} (${ctx.icons.toLocaleString()} icons)`,
    `Packs enabled  : ${ctx.enabledPacks}`,
    "",
    "Please describe what you did, what you expected, and what happened:",
    "",
    "1. Steps to reproduce:",
    "   - ",
    "2. Expected:",
    "   - ",
    "3. Actual:",
    "   - ",
    "4. Any console errors (Ctrl+Shift+I \u2192 Console):",
    "   - "
  ];
  return lines.join("\n");
}
var ReportBugModal = class extends import_obsidian6.Modal {
  constructor(app, ctx) {
    super(app);
    this.ctx = ctx;
  }
  onOpen() {
    const { contentEl } = this;
    this.titleEl.setText("Report a bug");
    contentEl.createDiv({
      cls: "setting-item-description",
      text: "Copy the diagnostic report below, fill in what happened, and paste it into a GitHub issue (or the Obsidian forum thread)."
    });
    const report = buildBugReport(this.ctx);
    const textarea = contentEl.createEl("textarea", {
      cls: "si-textarea",
      attr: { rows: "16", readonly: "", spellcheck: "false" }
    });
    textarea.value = report;
    new import_obsidian6.Setting(contentEl).addButton(
      (b) => b.setButtonText("Copy report").setCta().onClick(() => {
        void navigator.clipboard.writeText(report);
        new import_obsidian6.Notice("Bug report copied to clipboard");
      })
    ).addButton(
      (b) => b.setButtonText("Close").onClick(() => this.close())
    );
    if (this.ctx.reportUrl) {
      new import_obsidian6.Setting(contentEl).setDesc("Open the project's issue tracker in your browser.").addButton(
        (b) => b.setButtonText("Open issue page").onClick(() => {
          window.open(this.ctx.reportUrl, "_blank");
        })
      );
    }
  }
  onClose() {
    this.contentEl.empty();
  }
};

// src/ui/iconManager.ts
var import_obsidian10 = require("obsidian");

// src/ui/packFilter.ts
var import_obsidian7 = require("obsidian");
var PackFilterControl = class {
  constructor(opts) {
    this.opts = opts;
    this.root = null;
    this.btn = null;
    this.popover = null;
    this.search = "";
    this.searchInput = null;
    this.onDocMouseDown = (ev) => {
      if (this.root && !this.root.contains(ev.target)) this.close();
    };
    this.onKeyDown = (ev) => {
      if (ev.key === "Escape") this.close();
    };
  }
  /** Mount into a container; returns the root element. */
  mount(container) {
    this.root = container.createDiv({ cls: "si-pack-filter" });
    this.btn = this.root.createEl("button", {
      cls: "si-pack-filter-btn",
      attr: { type: "button", "aria-label": "Filter by pack" }
    });
    this.btn.addEventListener("click", (ev) => {
      ev.stopPropagation();
      this.toggle();
    });
    this.updateLabel();
    return this.root;
  }
  /** Refresh button label and (if open) the popover list. */
  update() {
    this.updateLabel();
    if (this.popover) this.renderPopover();
  }
  close() {
    this.popover?.remove();
    this.popover = null;
    document.removeEventListener("mousedown", this.onDocMouseDown);
    document.removeEventListener("keydown", this.onKeyDown);
  }
  /* --- internals -------------------------------------------------------- */
  updateLabel() {
    if (!this.btn) return;
    this.btn.empty();
    const store = this.opts.store;
    const pack = this.opts.getCurrent();
    const ic = this.btn.createSpan({ cls: "si-pack-filter-icon" });
    if (pack === "all") {
      renderIcon(ic, "layers");
      this.btn.createSpan({ text: `All packs \xB7 ${store.totalCount().toLocaleString()}` });
    } else {
      renderIcon(ic, `si-${pack}-${PACK_SAMPLE_ICON[pack] ?? "home"}`);
      this.btn.createSpan({ text: PACK_LABELS[pack] ?? pack });
    }
    const chev = this.btn.createSpan({ cls: "si-pack-filter-chev" });
    (0, import_obsidian7.setIcon)(chev, "chevron-down");
  }
  toggle() {
    if (this.popover) this.close();
    else this.open();
  }
  open() {
    if (!this.root || !this.btn) return;
    this.popover = this.root.createDiv({ cls: "si-pack-filter-pop" });
    const manager = this.root.closest(".si-manager");
    if (manager) fitPopoverToPane(this.popover, this.btn, manager);
    const head = this.popover.createDiv({ cls: "si-pf-head" });
    head.createSpan({ cls: "si-pf-title", text: "Packs" });
    const closeBtn = head.createEl("button", { cls: "si-icon-btn", attr: { type: "button" } });
    (0, import_obsidian7.setIcon)(closeBtn, "x");
    closeBtn.addEventListener("click", () => this.close());
    const searchWrap = this.popover.createDiv({ cls: "si-search si-pf-search" });
    const searchIcon = searchWrap.createSpan({ cls: "si-search-icon" });
    renderIcon(searchIcon, "search");
    this.searchInput = searchWrap.createEl("input", {
      cls: "si-search-input",
      attr: { placeholder: "Search packs\u2026", spellcheck: "false" }
    });
    this.searchInput.addEventListener("input", () => {
      this.search = this.searchInput?.value ?? "";
      if (this.popover) this.renderPopover();
    });
    const list = this.popover.createDiv({ cls: "si-pf-list" });
    void list;
    this.renderPopover();
    document.addEventListener("mousedown", this.onDocMouseDown);
    document.addEventListener("keydown", this.onKeyDown);
    window.setTimeout(() => this.searchInput?.focus(), 30);
  }
  renderPopover() {
    if (!this.popover) return;
    const list = this.popover.querySelector(".si-pf-list");
    if (!list) return;
    list.empty();
    const q = this.search.trim().toLowerCase();
    const renderRow = (pack) => {
      if (q && !(PACK_LABELS[pack] ?? pack).toLowerCase().includes(q)) return;
      const store = this.opts.store;
      const enabled = store.packEnabled(pack);
      const row = list.createDiv({
        cls: "si-pf-row" + (this.opts.getCurrent() === pack ? " is-current" : "") + (enabled ? "" : " is-off")
      });
      const cb = row.createEl("input", { attr: { type: "checkbox" } });
      cb.checked = enabled;
      cb.addEventListener("change", (ev) => {
        ev.stopPropagation();
        void (async () => {
          if (cb.checked) await store.enablePack(pack);
          else await store.disablePack(pack);
          this.update();
        })();
      });
      const ic = row.createSpan({ cls: "si-pf-icon" });
      renderIcon(ic, `si-${pack}-${PACK_SAMPLE_ICON[pack] ?? "home"}`);
      row.createSpan({ cls: "si-pf-label", text: PACK_LABELS[pack] ?? pack });
      row.createSpan({ cls: "si-pf-count", text: store.getPackCount(pack).toLocaleString() });
      row.addEventListener("click", () => {
        if (!enabled) void store.enablePack(pack);
        this.opts.onSelect(pack);
        this.close();
      });
    };
    const renderAll = () => {
      const row = list.createDiv({ cls: "si-pf-row" + (this.opts.getCurrent() === "all" ? " is-current" : "") });
      const ic = row.createSpan({ cls: "si-pf-icon" });
      renderIcon(ic, "layers");
      row.createSpan({ cls: "si-pf-label", text: "All packs" });
      row.createSpan({ cls: "si-pf-count", text: this.opts.store.totalCount().toLocaleString() });
      row.addEventListener("click", () => {
        this.opts.onSelect("all");
        this.close();
      });
    };
    if (q) {
      for (const pack of ALL_PACKS) renderRow(pack);
    } else {
      renderAll();
      const userCount = this.opts.store.userIcons().length;
      if (userCount > 0) {
        list.createDiv({ cls: "si-pf-group-title", text: `My icons (${userCount})` });
        renderRow("user");
      }
      for (const group of PACK_GROUPS) {
        const title = list.createDiv({ cls: "si-pf-group-title", text: group.title });
        void title;
        for (const pack of group.packs) renderRow(pack);
      }
    }
    if (list.children.length === 0) {
      list.createDiv({ cls: "si-empty", text: "No packs match" });
    }
  }
};

// src/ui/collectionFilter.ts
var import_obsidian8 = require("obsidian");
var CollectionFilterControl = class {
  constructor(opts) {
    this.opts = opts;
    this.root = null;
    this.btn = null;
    this.popover = null;
    this.onDocMouseDown = (ev) => {
      if (this.root && !this.root.contains(ev.target)) this.close();
    };
    this.onKeyDown = (ev) => {
      if (ev.key === "Escape") this.close();
    };
  }
  mount(container) {
    this.root = container.createDiv({ cls: "si-pack-filter" });
    this.btn = this.root.createEl("button", {
      cls: "si-pack-filter-btn",
      attr: { type: "button", "aria-label": "Browse collections" }
    });
    this.btn.addEventListener("click", (ev) => {
      ev.stopPropagation();
      this.toggle();
    });
    this.updateLabel();
    return this.root;
  }
  update() {
    this.updateLabel();
    if (this.popover) this.renderPopover();
  }
  close() {
    this.popover?.remove();
    this.popover = null;
    document.removeEventListener("mousedown", this.onDocMouseDown);
    document.removeEventListener("keydown", this.onKeyDown);
  }
  /* --- internals -------------------------------------------------------- */
  updateLabel() {
    if (!this.btn) return;
    this.btn.empty();
    const current = this.opts.getCurrent();
    const ic = this.btn.createSpan({ cls: "si-pack-filter-icon" });
    if (current) {
      renderIcon(ic, current.iconIds[0] ?? "si-lucide-folder");
      this.btn.createSpan({ text: current.name });
    } else {
      renderIcon(ic, "folder");
      this.btn.createSpan({ text: "Collections" });
    }
    const chev = this.btn.createSpan({ cls: "si-pack-filter-chev" });
    (0, import_obsidian8.setIcon)(chev, "chevron-down");
  }
  toggle() {
    if (this.popover) this.close();
    else this.open();
  }
  open() {
    if (!this.root || !this.btn) return;
    this.popover = this.root.createDiv({ cls: "si-pack-filter-pop" });
    const manager = this.root.closest(".si-manager");
    if (manager) fitPopoverToPane(this.popover, this.btn, manager);
    const head = this.popover.createDiv({ cls: "si-pf-head" });
    head.createSpan({ cls: "si-pf-title", text: "Collections" });
    const closeBtn = head.createEl("button", { cls: "si-icon-btn", attr: { type: "button" } });
    (0, import_obsidian8.setIcon)(closeBtn, "x");
    closeBtn.addEventListener("click", () => this.close());
    const list = this.popover.createDiv({ cls: "si-pf-list" });
    this.renderPopover();
    document.addEventListener("mousedown", this.onDocMouseDown);
    document.addEventListener("keydown", this.onKeyDown);
  }
  renderPopover() {
    if (!this.popover) return;
    const list = this.popover.querySelector(".si-pf-list");
    if (!list) return;
    list.empty();
    const store = this.opts.store;
    const current = this.opts.getCurrent();
    const renderRow = (label, iconId2, count, isCurrent, onClick) => {
      const row = list.createDiv({ cls: "si-pf-row" + (isCurrent ? " is-current" : "") });
      const ic2 = row.createSpan({ cls: "si-pf-icon" });
      renderIcon(ic2, iconId2);
      row.createSpan({ cls: "si-pf-label", text: label });
      if (count !== null) row.createSpan({ cls: "si-pf-count", text: count });
      row.addEventListener("click", onClick);
    };
    renderRow("All icons", "layers", null, current === null, () => {
      this.opts.onSelect(null);
      this.close();
    });
    const collections = store.getSettings().collections;
    if (collections.length === 0) {
      list.createDiv({ cls: "si-empty", text: "No collections yet" });
    }
    for (const col of collections) {
      renderRow(col.name, col.iconIds[0] ?? "si-lucide-folder", String(col.iconIds.length), current?.id === col.id, () => {
        this.opts.onSelect(col);
        this.close();
      });
    }
    const newRow = list.createDiv({ cls: "si-pf-row si-pf-new" });
    const ic = newRow.createSpan({ cls: "si-pf-icon" });
    renderIcon(ic, "plus");
    newRow.createSpan({ cls: "si-pf-label", text: "New collection\u2026" });
    newRow.addEventListener("click", () => {
      void (async () => {
        const col = await this.opts.onCreate();
        if (col) {
          this.opts.onSelect(col);
          this.close();
        }
      })();
    });
  }
};

// src/ui/iconPicker.ts
var import_obsidian9 = require("obsidian");
var IconPickerModal = class extends import_obsidian9.Modal {
  constructor(app, storeProvider, opts) {
    super(app);
    this.storeProvider = storeProvider;
    this.opts = opts;
    this.query = "";
    this.showFavoritesOnly = false;
    this.selectedIndex = 0;
    this.pickerLimit = 400;
    this.results = [];
    this.store = storeProvider();
    this.packFilter = opts.packFilter ?? "all";
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.addClass("si-picker");
    const header = contentEl.createDiv({ cls: "si-picker-header" });
    header.createDiv({ cls: "si-picker-title", text: this.opts.title ?? "Pick an icon" });
    const searchRow = contentEl.createDiv({ cls: "si-search-row" });
    const searchWrap = searchRow.createDiv({ cls: "si-search" });
    const searchIcon = searchWrap.createSpan({ cls: "si-search-icon" });
    renderIcon(searchIcon, "search");
    const input = searchWrap.createEl("input", {
      cls: "si-search-input",
      attr: { placeholder: "Search icons\u2026 (try \u201Cfolder\u201D, \u201Cstar\u201D, \u201Chome\u201D)", spellcheck: "false" }
    });
    searchRow.appendChild(searchWrap);
    const chips = contentEl.createDiv({ cls: "si-chips si-picker-chips" });
    const packFilter = new PackFilterControl({
      store: this.store,
      getCurrent: () => this.packFilter,
      onSelect: (pack) => {
        this.packFilter = pack;
        this.pickerLimit = 400;
        this.selectedIndex = 0;
        this.renderGrid();
      }
    });
    packFilter.mount(chips);
    const favChip = chips.createEl("button", {
      cls: "si-chip" + (this.showFavoritesOnly ? " is-active" : ""),
      attr: { type: "button" }
    });
    const favIc = favChip.createSpan({ cls: "si-chip-icon" });
    (0, import_obsidian9.setIcon)(favIc, "star");
    favChip.createSpan({ text: "Favorites" });
    favChip.addEventListener("click", () => {
      this.showFavoritesOnly = !this.showFavoritesOnly;
      favChip.toggleClass("is-active", this.showFavoritesOnly);
      this.selectedIndex = 0;
      this.renderGrid();
    });
    if (this.opts.allowNone) {
      const noneChip = chips.createEl("button", { cls: "si-chip", attr: { type: "button" } });
      noneChip.createSpan({ text: "\u2715 No icon" });
      noneChip.addEventListener("click", () => {
        this.opts.onPick(null);
        this.close();
      });
    }
    this.gridEl = contentEl.createDiv({ cls: "si-picker-grid" });
    const footer = contentEl.createDiv({ cls: "si-picker-footer" });
    this.footerIconEl = footer.createSpan({ cls: "si-footer-icon" });
    this.footerNameEl = footer.createSpan({ cls: "si-footer-name", text: "No selection" });
    const actions = footer.createDiv({ cls: "si-footer-actions" });
    const copyName = actions.createEl("button", { cls: "si-btn", attr: { type: "button" } });
    copyName.createSpan({ text: "Copy name" });
    copyName.addEventListener("click", () => this.copySelected("name"));
    const copySvg = actions.createEl("button", { cls: "si-btn", attr: { type: "button" } });
    copySvg.createSpan({ text: "Copy SVG" });
    copySvg.addEventListener("click", () => this.copySelected("svg"));
    const selectBtn = actions.createEl("button", {
      cls: "si-btn si-btn-primary",
      attr: { type: "button" }
    });
    selectBtn.createSpan({ text: "Select" });
    selectBtn.addEventListener("click", () => {
      const icon = this.results[this.selectedIndex];
      if (icon) this.pick(icon);
    });
    const doSearch = debounce(() => {
      this.selectedIndex = 0;
      this.renderGrid();
    }, 120);
    input.addEventListener("input", () => {
      this.query = input.value;
      this.pickerLimit = 400;
      doSearch();
    });
    input.addEventListener("keydown", (ev) => this.onKey(ev, input));
    this.renderGrid();
    window.setTimeout(() => input.focus(), 50);
  }
  onClose() {
    this.contentEl.empty();
  }
  onKey(ev, input) {
    if (ev.key === "ArrowDown" || ev.key === "ArrowUp") {
      ev.preventDefault();
      const dir = ev.key === "ArrowDown" ? 1 : -1;
      this.selectedIndex = clamp(this.selectedIndex + dir, 0, Math.max(0, this.results.length - 1));
      this.highlight();
    } else if (ev.key === "ArrowLeft" || ev.key === "ArrowRight") {
      ev.preventDefault();
      const dir = ev.key === "ArrowRight" ? 1 : -1;
      this.selectedIndex = clamp(this.selectedIndex + dir * 6, 0, Math.max(0, this.results.length - 1));
      this.highlight();
    } else if (ev.key === "Enter") {
      ev.preventDefault();
      const icon = this.results[this.selectedIndex];
      if (icon) this.pick(icon);
    } else if (ev.key === "Escape") {
      this.close();
    }
    void input;
  }
  pick(icon) {
    void this.store.pushRecent(icon.id);
    this.opts.onPick(icon);
    this.close();
  }
  copySelected(kind) {
    const icon = this.results[this.selectedIndex];
    if (!icon) return;
    navigator.clipboard.writeText(kind === "name" ? icon.id : svgForClipboard(icon.svg)).then(() => {
      new import_obsidian9.Notice("Copied " + (kind === "name" ? icon.id : "SVG") + " to clipboard");
    });
  }
  highlight() {
    this.gridEl.querySelectorAll(".si-tile.is-selected").forEach((el) => el.removeClass("is-selected"));
    const tiles = this.gridEl.querySelectorAll(".si-tile");
    const tile = tiles[this.selectedIndex];
    tile?.addClass("is-selected");
    tile?.scrollIntoView({ block: "nearest" });
    this.updateFooter();
  }
  updateFooter() {
    const icon = this.results[this.selectedIndex];
    if (!icon) {
      this.footerIconEl.empty();
      this.footerNameEl.setText("No selection");
      return;
    }
    renderIcon(this.footerIconEl, icon.id, 18);
    this.footerNameEl.setText(`${icon.id}  \xB7  ${icon.tags.slice(0, 4).join(", ")}`);
  }
  renderGrid() {
    this.gridEl.empty();
    const all = this.showFavoritesOnly ? this.store.favoriteIcons() : this.store.search(this.query, this.packFilter, 5e3);
    const icons = all.slice(0, this.pickerLimit);
    const sections = [];
    if (!this.query.trim() && !this.showFavoritesOnly) {
      const recents = this.store.recentIcons().filter((i) => this.packFilter === "all" || i.pack === this.packFilter);
      if (recents.length) sections.push({ title: "Recent", icons: recents.slice(0, 18) });
      const favs = this.store.favoriteIcons().filter((i) => this.packFilter === "all" || i.pack === this.packFilter);
      if (favs.length) sections.push({ title: "Favorites", icons: favs.slice(0, 24) });
      sections.push({ title: "All icons", icons });
    } else {
      sections.push({ title: this.query.trim() ? `Results (${all.length})` : "Icons", icons });
    }
    this.results = sections.flatMap((s) => s.icons);
    if (this.results.length === 0) {
      const pack = this.packFilter;
      if (pack !== "all" && !this.store.packEnabled(pack)) {
        const box = this.gridEl.createDiv({ cls: "si-empty" });
        box.createDiv({ cls: "si-empty-text", text: `${PACK_LABELS[pack] ?? pack} is not enabled` });
        box.createDiv({ cls: "si-empty-hint", text: "Enable the pack to pick from it." });
        const btn = box.createEl("button", { cls: "si-btn si-btn-primary", attr: { type: "button" } });
        btn.createSpan({ text: "Enable pack" });
        btn.addEventListener("click", async () => {
          await this.store.enablePack(pack);
          this.renderGrid();
        });
        return;
      }
      this.gridEl.appendChild(emptyState("No icons found", "Try a different search or pack."));
      return;
    }
    let tileIndex = 0;
    for (const section of sections) {
      if (section.icons.length === 0) continue;
      const head = this.gridEl.createDiv({ cls: "si-section-title", text: section.title });
      void head;
      const grid = this.gridEl.createDiv({ cls: "si-grid" });
      for (const icon of section.icons) {
        const idx = tileIndex++;
        const isFav = this.store.isFavorite(icon.id);
        const tile = iconTile(icon, {
          selected: idx === this.selectedIndex,
          onPick: (i) => this.pick(i),
          onStar: (i) => void this.store.toggleFavorite(i.id),
          onContext: (i, ev) => {
            ev.preventDefault();
            this.selectedIndex = idx;
            this.highlight();
            new import_obsidian9.Menu().addItem((item) => {
              item.setTitle(isFav ? "Remove from favorites" : "Add to favorites").setIcon("star").onClick(() => {
                void this.store.toggleFavorite(i.id);
                this.renderGrid();
              });
            }).addItem((item) => {
              item.setTitle("Copy icon name").onClick(() => {
                navigator.clipboard.writeText(i.id);
              });
            }).addItem((item) => {
              item.setTitle("Copy SVG").onClick(() => {
                navigator.clipboard.writeText(i.svg);
              });
            }).showAtMouseEvent(ev);
          }
        });
        if (idx === this.selectedIndex) tile.addClass("is-selected");
        grid.appendChild(tile);
      }
    }
    if (all.length > this.pickerLimit) {
      const more = this.gridEl.createDiv({ cls: "si-more-row" });
      more.createSpan({
        cls: "si-more-count",
        text: `Showing ${this.pickerLimit.toLocaleString()} of ${all.length.toLocaleString()}`
      });
      const btn = more.createEl("button", { cls: "si-btn", attr: { type: "button" } });
      btn.createSpan({ text: "Show more" });
      btn.addEventListener("click", () => {
        this.pickerLimit += 500;
        this.renderGrid();
      });
    }
    this.updateFooter();
  }
};

// src/ui/iconManager.ts
var ICON_MANAGER_VIEW_TYPE = "star-icons-manager";
var IconManagerView = class extends import_obsidian10.ItemView {
  constructor(leaf, plugin) {
    super(leaf);
    this.plugin = plugin;
    this.filter = { pack: "all", tag: null, query: "" };
    this.selectedCollection = null;
    this.selectedId = null;
    this.visibleLimit = 600;
    this.filterSignature = "";
  }
  getViewType() {
    return ICON_MANAGER_VIEW_TYPE;
  }
  getDisplayText() {
    return "Star Icons";
  }
  getIcon() {
    return brandIconId();
  }
  async onOpen() {
    this.buildDom();
    this.unsub = this.plugin.store.subscribe(() => this.render());
    this.render();
    this.resizeObserver = new ResizeObserver(() => this.handleResize());
    this.resizeObserver.observe(this.contentEl);
    this.handleResize();
  }
  async onClose() {
    this.unsub?.();
    this.resizeObserver?.disconnect();
    this.contentEl.empty();
  }
  /**
   * Tracks the manager's actual width and collapses chrome when the pane is
   * too narrow (the icon grid must never be squeezed out of existence).
   */
  handleResize() {
    const width = this.contentEl.clientWidth;
    this.contentEl.toggleClass("is-narrow", width > 0 && width < 720);
  }
  /** Close the sidebar overlay on narrow panes after making a selection. */
  closeSideIfNarrow() {
    if (this.contentEl.hasClass("is-narrow")) this.contentEl.removeClass("si-side-open");
  }
  /* --- DOM scaffold ------------------------------------------------------ */
  buildDom() {
    const root = this.contentEl;
    root.addClass("si-manager");
    root.empty();
    const header = root.createDiv({ cls: "si-manager-header" });
    const titleWrap = header.createDiv({ cls: "si-manager-title" });
    const brand = titleWrap.createSpan({ cls: "si-manager-brand" });
    renderIcon(brand, brandIconId(), 22);
    titleWrap.createSpan({ cls: "si-manager-name", text: "Star Icons" });
    this.headerTitleEl = titleWrap.createSpan({ cls: "si-manager-sub" });
    const searchWrap = header.createDiv({ cls: "si-search si-manager-search" });
    const searchIcon = searchWrap.createSpan({ cls: "si-search-icon" });
    renderIcon(searchIcon, "search");
    this.searchEl = searchWrap.createEl("input", {
      cls: "si-search-input",
      attr: { placeholder: "Search icons\u2026", spellcheck: "false" }
    });
    this.searchEl.addEventListener("input", () => {
      this.filter.query = this.searchEl.value;
      this.renderMain();
    });
    const toolbar = header.createDiv({ cls: "si-manager-toolbar" });
    this.packFilterControl = new PackFilterControl({
      store: this.plugin.store,
      getCurrent: () => this.filter.pack,
      onSelect: (pack) => {
        this.filter.pack = pack;
        this.render();
      }
    });
    this.packFilterControl.mount(toolbar);
    this.collectionFilterControl = new CollectionFilterControl({
      store: this.plugin.store,
      getCurrent: () => this.selectedCollection,
      onSelect: (col) => {
        this.selectedCollection = col;
        this.selectedId = null;
        if (col) this.filter = { ...this.filter, tag: null };
        this.closeSideIfNarrow();
        this.render();
      },
      onCreate: async () => {
        const name = await this.promptText("Collection name", "My icons");
        if (!name) return null;
        return this.plugin.store.createCollection(name);
      }
    });
    this.collectionFilterControl.mount(toolbar);
    const toolbarRight = toolbar.createDiv({ cls: "si-manager-toolbar-right" });
    const addIconBtn = toolbarRight.createEl("button", {
      cls: "si-btn si-btn-small",
      attr: { type: "button", "aria-label": "Add your own icon" }
    });
    (0, import_obsidian10.setIcon)(addIconBtn, "upload");
    addIconBtn.createSpan({ text: "Add icon" });
    addIconBtn.addEventListener("click", (ev) => {
      new import_obsidian10.Menu().addItem((i) => i.setTitle("Import SVG file(s)\u2026").setIcon("upload").onClick(() => this.importSvgFiles())).addItem((i) => i.setTitle("Paste SVG code\u2026").setIcon("clipboard").onClick(() => void this.pasteSvg())).showAtMouseEvent(ev);
    });
    const sideToggle = toolbarRight.createEl("button", {
      cls: "si-btn si-btn-small si-side-toggle",
      attr: { type: "button", "aria-label": "Toggle collections panel" }
    });
    renderIcon(sideToggle, "panel-left");
    sideToggle.addEventListener("click", () => {
      this.contentEl.classList.toggle("si-side-open");
    });
    const density = toolbarRight.createDiv({ cls: "si-manager-density" });
    density.appendChild(
      segmentedControl(
        [
          { value: "comfortable", label: "Comfortable" },
          { value: "compact", label: "Compact" }
        ],
        this.plugin.settings.iconGridDensity,
        (v) => {
          this.plugin.settings.iconGridDensity = v;
          void this.plugin.saveSettings();
          this.renderMain();
        }
      )
    );
    const body = root.createDiv({ cls: "si-manager-body" });
    this.sideEl = body.createDiv({ cls: "si-manager-side" });
    this.mainEl = body.createDiv({ cls: "si-manager-main" });
    this.detailEl = body.createDiv({ cls: "si-manager-detail" });
  }
  /* --- rendering ---------------------------------------------------------- */
  render() {
    this.renderHeader();
    this.renderSidebar();
    this.renderMain();
    this.renderDetail();
    this.packFilterControl?.update();
    this.collectionFilterControl?.update();
  }
  renderHeader() {
    const store = this.plugin.store;
    const total = store.totalCount();
    this.headerTitleEl.setText(`${total.toLocaleString()} icons \xB7 ${ALL_PACKS.length} packs \xB7 offline`);
  }
  renderSidebar() {
    const side = this.sideEl;
    side.empty();
    const store = this.plugin.store;
    const colSection = side.createDiv({ cls: "si-side-section" });
    const colHead = colSection.createDiv({ cls: "si-side-head" });
    colHead.createSpan({ cls: "si-side-title", text: "Collections" });
    const addCol = colHead.createEl("button", {
      cls: "si-icon-btn",
      attr: { type: "button", "aria-label": "New collection" }
    });
    (0, import_obsidian10.setIcon)(addCol, "plus");
    addCol.addEventListener("click", async () => {
      const name = await this.promptText("Collection name", "My icons");
      if (!name) return;
      const col = await store.createCollection(name);
      this.selectedCollection = col;
      this.filter = { ...this.filter, tag: null };
      this.closeSideIfNarrow();
      this.render();
    });
    colSection.appendChild(colHead);
    const colList = colSection.createDiv({ cls: "si-side-list" });
    if (this.plugin.settings.collections.length === 0) {
      colList.appendChild(emptyState("No collections yet", "Drag icons here or use +"));
    }
    for (const col of store.getSettings().collections) {
      const item = colList.createDiv({
        cls: "si-side-item" + (this.selectedCollection?.id === col.id ? " is-active" : ""),
        attr: { draggable: "false" }
      });
      const icon = item.createSpan({ cls: "si-side-item-icon" });
      renderIcon(icon, col.iconIds[0] ?? "si-lucide-folder");
      item.createSpan({ cls: "si-side-item-label", text: col.name });
      item.createSpan({ cls: "si-side-item-count", text: String(col.iconIds.length) });
      item.addEventListener("click", () => {
        this.selectedCollection = col;
        this.selectedId = null;
        this.closeSideIfNarrow();
        this.render();
      });
      item.addEventListener("dragover", (ev) => {
        ev.preventDefault();
        item.addClass("is-drag-target");
      });
      item.addEventListener("dragleave", () => item.removeClass("is-drag-target"));
      item.addEventListener("drop", (ev) => {
        ev.preventDefault();
        item.removeClass("is-drag-target");
        const id = ev.dataTransfer?.getData("text/plain");
        if (id && getIcon(id)) void store.addToCollection(col.id, id);
      });
      item.addEventListener("contextmenu", (ev) => {
        ev.preventDefault();
        new import_obsidian10.Menu().addItem((i) => {
          i.setTitle("Rename").setIcon("pencil").onClick(async () => {
            const name = await this.promptText("Rename collection", col.name);
            if (name) void store.renameCollection(col.id, name);
          });
        }).addItem((i) => {
          i.setTitle("Delete").setIcon("trash").onClick(() => void store.deleteCollection(col.id));
        }).showAtMouseEvent(ev);
      });
    }
    const tagSection = side.createDiv({ cls: "si-side-section" });
    const tagHead = tagSection.createDiv({ cls: "si-side-head" });
    tagHead.createSpan({ cls: "si-side-title", text: "Tags" });
    const clearTags = tagHead.createEl("button", {
      cls: "si-icon-btn",
      attr: { type: "button", "aria-label": "Delete all tags" }
    });
    (0, import_obsidian10.setIcon)(clearTags, "trash");
    clearTags.addEventListener("click", async () => {
      const ok = await confirmDialog(this.app, {
        title: "Delete all user tags?",
        message: "Every custom tag will be removed from all icons.",
        confirmLabel: "Delete all",
        danger: true
      });
      if (!ok) return;
      this.filter.tag = null;
      await store.clearAllUserTags();
    });
    const tagList = tagSection.createDiv({ cls: "si-side-list" });
    const allTags = store.allUserTags();
    if (allTags.length === 0) {
      tagList.appendChild(emptyState("No user tags", "Tag icons from the detail panel"));
    }
    for (const tag of allTags) {
      const item = tagList.createDiv({
        cls: "si-side-item" + (this.filter.tag === tag ? " is-active" : "")
      });
      const icon = item.createSpan({ cls: "si-side-item-icon" });
      renderIcon(icon, "tag");
      item.createSpan({ cls: "si-side-item-label", text: tag });
      item.addEventListener("click", () => {
        this.filter.tag = this.filter.tag === tag ? null : tag;
        this.selectedCollection = null;
        this.closeSideIfNarrow();
        this.render();
      });
      item.addEventListener("contextmenu", (ev) => {
        ev.preventDefault();
        new import_obsidian10.Menu().addItem(
          (i) => i.setTitle("Filter by this tag").setIcon("tag").onClick(() => {
            this.filter.tag = this.filter.tag === tag ? null : tag;
            this.selectedCollection = null;
            this.render();
          })
        ).addItem(
          (i) => i.setTitle("Rename tag").setIcon("pencil").onClick(async () => {
            const name = await this.promptText("Rename tag", tag);
            if (name && name !== tag) await store.renameUserTag(tag, name);
          })
        ).addItem(
          (i) => i.setTitle("Delete tag").setIcon("trash").onClick(async () => {
            const ok = await confirmDialog(this.app, {
              title: `Delete tag \u201C${tag}\u201D?`,
              message: "It will be removed from every icon that uses it.",
              confirmLabel: "Delete",
              danger: true
            });
            if (ok) await store.deleteUserTag(tag);
          })
        ).addSeparator().addItem(
          (i) => i.setTitle("Delete ALL tags").setIcon("trash").onClick(async () => {
            const ok = await confirmDialog(this.app, {
              title: "Delete all user tags?",
              message: "Every custom tag will be removed from all icons.",
              confirmLabel: "Delete all",
              danger: true
            });
            if (!ok) return;
            this.filter.tag = null;
            await store.clearAllUserTags();
          })
        ).showAtMouseEvent(ev);
      });
    }
    const packSection = side.createDiv({ cls: "si-side-section" });
    const packDetails = packSection.createEl("details", { cls: "si-side-details" });
    packDetails.setAttr("open", "");
    const packSummary = packDetails.createEl("summary", { cls: "si-side-title" });
    packSummary.createSpan({ text: `Packs (${ALL_PACKS.length})` });
    for (const pack of ALL_PACKS) {
      const row = packDetails.createDiv({ cls: "si-side-item si-side-static" });
      const ic = row.createSpan({ cls: "si-side-item-icon" });
      renderIcon(ic, `si-${pack}-${PACK_SAMPLE_ICON[pack] ?? "home"}`);
      row.createSpan({ cls: "si-side-item-label", text: `${PACK_LABELS[pack] ?? pack} v${this.plugin.store.getPackVersion(pack)}` });
      row.createSpan({ cls: "si-side-item-count", text: String(this.plugin.store.getPackCount(pack)) });
    }
  }
  renderMain() {
    const main = this.mainEl;
    main.empty();
    const store = this.plugin.store;
    if (this.selectedCollection) {
      const fresh = store.getSettings().collections.find(
        (c) => c.id === this.selectedCollection?.id
      );
      if (fresh) {
        this.renderCollectionDetail(main, fresh);
        return;
      }
      this.selectedCollection = null;
    }
    const icons = this.collectIcons();
    if (icons.length === 0) {
      const pack = this.filter.pack;
      if (pack !== "all") {
        if (!store.packEnabled(pack)) {
          const box = main.createDiv({ cls: "si-empty" });
          box.createDiv({ cls: "si-empty-icon", text: "\u{1F512}" });
          box.createDiv({ cls: "si-empty-text", text: `${PACK_LABELS[pack] ?? pack} is not enabled` });
          box.createDiv({
            cls: "si-empty-hint",
            text: `${store.getPackCount(pack).toLocaleString()} icons are available \u2014 enable the pack to browse them.`
          });
          const btn = box.createEl("button", { cls: "si-btn si-btn-primary", attr: { type: "button" } });
          btn.createSpan({ text: "Enable pack" });
          btn.addEventListener("click", async () => {
            await store.enablePack(pack);
            this.render();
          });
          main.appendChild(box);
          return;
        }
        if (!store.isPackLoaded(pack)) {
          main.appendChild(emptyState("Loading icons\u2026", `${PACK_LABELS[pack] ?? pack} is loading from disk.`));
          void store.loadPack(pack);
          return;
        }
      }
      main.appendChild(emptyState("No icons match", "Clear the search or switch packs."));
      return;
    }
    const shown = icons.slice(0, this.visibleLimit);
    const grid = main.createDiv({ cls: "si-grid " + this.plugin.settings.iconGridDensity });
    for (const icon of shown) {
      grid.appendChild(this.buildTile(icon));
    }
    if (icons.length > shown.length) {
      const more = main.createDiv({ cls: "si-more-row" });
      more.createSpan({
        cls: "si-more-count",
        text: `Showing ${shown.length.toLocaleString()} of ${icons.length.toLocaleString()} icons`
      });
      const btn = more.createEl("button", { cls: "si-btn", attr: { type: "button" } });
      btn.createSpan({ text: "Show more" });
      btn.addEventListener("click", () => {
        this.visibleLimit += 1e3;
        this.renderMain();
      });
      main.appendChild(more);
    }
    grid.addEventListener("dragstart", (ev) => {
      const tile = ev.target.closest?.(".si-tile");
      if (!tile) return;
      ev.dataTransfer?.setData("text/plain", tile.getAttribute("data-icon-id") ?? "");
      if (ev.dataTransfer) ev.dataTransfer.effectAllowed = "copy";
    });
  }
  renderCollectionDetail(main, col) {
    const store = this.plugin.store;
    const head = main.createDiv({ cls: "si-col-head" });
    const back = head.createEl("button", { cls: "si-btn si-btn-small", attr: { type: "button" } });
    back.createSpan({ text: "\u2190 All icons" });
    back.addEventListener("click", () => {
      this.selectedCollection = null;
      this.render();
    });
    const title = head.createDiv({ cls: "si-col-title" });
    title.createSpan({ text: col.name });
    title.createSpan({ cls: "si-col-count", text: `${col.iconIds.length} icons` });
    const addIcon2 = head.createEl("button", { cls: "si-btn si-btn-small", attr: { type: "button" } });
    addIcon2.createSpan({ text: "+ Add icon" });
    addIcon2.addEventListener("click", () => {
      new IconPickerModal(this.app, () => store, {
        title: `Add to \u201C${col.name}\u201D`,
        onPick: (icon) => {
          if (icon) void store.addToCollection(col.id, icon.id);
        }
      }).open();
    });
    const deleteCol = head.createEl("button", { cls: "si-btn si-btn-small is-danger", attr: { type: "button" } });
    (0, import_obsidian10.setIcon)(deleteCol, "trash");
    deleteCol.createSpan({ text: "Delete" });
    deleteCol.addEventListener("click", async () => {
      const ok = await confirmDialog(this.app, {
        title: `Delete collection \u201C${col.name}\u201D?`,
        message: "The collection will be removed. Its icons stay in your library.",
        confirmLabel: "Delete",
        danger: true
      });
      if (!ok) return;
      this.selectedCollection = null;
      await store.deleteCollection(col.id);
    });
    head.appendChild(addIcon2);
    head.appendChild(deleteCol);
    const list = main.createDiv({ cls: "si-col-list" });
    if (col.iconIds.length === 0) {
      list.appendChild(emptyState("Collection is empty", "Click \u201C+ Add icon\u201D or drag tiles from the grid onto a collection."));
    }
    col.iconIds.forEach((id, index) => {
      const def = getIcon(id);
      const row = list.createDiv({ cls: "si-col-item", attr: { draggable: "true", "data-index": String(index) } });
      const handle = row.createSpan({ cls: "si-drag-handle" });
      (0, import_obsidian10.setIcon)(handle, "grip-vertical");
      const ic = row.createSpan({ cls: "si-col-item-icon" });
      if (def) renderIcon(ic, def.id);
      const name = row.createSpan({ cls: "si-col-item-name", text: def ? def.id : id });
      void name;
      const remove = row.createEl("button", { cls: "si-icon-btn", attr: { type: "button" } });
      (0, import_obsidian10.setIcon)(remove, "x");
      remove.addEventListener("click", () => void store.removeFromCollection(col.id, id));
      list.appendChild(row);
    });
    makeSortable(list, {
      onReorder: (from, to) => void store.moveInCollection(col.id, from, to)
    });
  }
  collectIcons() {
    const store = this.plugin.store;
    let icons = store.availableIcons();
    if (this.filter.pack !== "all") icons = icons.filter((i) => i.pack === this.filter.pack);
    if (this.filter.tag) {
      const tag = this.filter.tag;
      icons = icons.filter((i) => store.userTagsFor(i.id).includes(tag));
    }
    if (this.filter.query.trim()) {
      const q = this.filter.query.trim().toLowerCase();
      icons = icons.filter(
        (i) => i.name.includes(q) || i.tags.some((t) => t.includes(q)) || i.id.includes(q)
      );
    }
    const signature = `${this.filter.pack}|${this.filter.tag ?? ""}|${this.filter.query.trim()}|${this.selectedCollection?.id ?? ""}`;
    if (signature !== this.filterSignature) {
      this.filterSignature = signature;
      this.visibleLimit = 600;
    }
    return icons;
  }
  buildTile(icon) {
    const store = this.plugin.store;
    const tile = iconTile(icon, {
      selected: this.selectedId === icon.id,
      onPick: (i) => {
        this.selectedId = this.selectedId === i.id ? null : i.id;
        this.renderDetail();
        this.renderMain();
      },
      onStar: (i) => void store.toggleFavorite(i.id),
      onContext: (i, ev) => {
        ev.preventDefault();
        new import_obsidian10.Menu().addItem((item) => {
          item.setTitle(store.isFavorite(i.id) ? "Remove from favorites" : "Add to favorites").setIcon("star").onClick(() => void store.toggleFavorite(i.id));
        }).addItem((item) => {
          item.setTitle("Add to collection\u2026").setIcon("folder-plus").onClick(() => this.showAddToCollection(i, ev));
        }).addItem((item) => {
          item.setTitle("Copy icon name").onClick(() => void navigator.clipboard.writeText(i.id));
        }).addItem((item) => {
          item.setTitle("Copy SVG").onClick(() => void navigator.clipboard.writeText(svgForClipboard(i.svg)));
        }).addItem((item) => {
          item.setTitle("Insert in note").onClick(() => this.insertIconAtCursor(i));
        }).addItem((item) => {
          if (i.pack === "user") {
            item.setTitle("Delete icon").setIcon("trash").onClick(() => void this.deleteUserIcon(i));
          }
        }).showAtMouseEvent(ev);
      }
    });
    tile.setAttribute("draggable", "true");
    return tile;
  }
  showAddToCollection(icon, ev) {
    const store = this.plugin.store;
    const menu = new import_obsidian10.Menu();
    for (const col of store.getSettings().collections) {
      menu.addItem((item) => {
        item.setTitle(col.iconIds.includes(icon.id) ? `${col.name} \u2713` : col.name).setIcon(col.iconIds.includes(icon.id) ? "check" : "folder").onClick(() => void store.addToCollection(col.id, icon.id));
      });
    }
    menu.addItem((item) => {
      item.setTitle("\uFF0B New collection\u2026").setIcon("plus").onClick(async () => {
        const name = await this.promptText("Collection name", "My icons");
        if (!name) return;
        const col = await store.createCollection(name);
        void store.addToCollection(col.id, icon.id);
      });
    });
    menu.showAtMouseEvent(ev);
  }
  renderDetail() {
    const detail = this.detailEl;
    detail.empty();
    const store = this.plugin.store;
    const id = this.selectedId;
    if (!id) {
      detail.addClass("is-empty");
      const hint = detail.createDiv({ cls: "si-detail-hint" });
      renderIcon(hint, brandIconId(), 40);
      hint.createEl("div", { cls: "si-detail-hint-text", text: "Select an icon" });
      return;
    }
    detail.removeClass("is-empty");
    const def = getIcon(id);
    if (!def) {
      this.selectedId = null;
      return;
    }
    const detailHead = detail.createDiv({ cls: "si-detail-head" });
    detailHead.createSpan({ cls: "si-detail-head-title", text: "Icon details" });
    const closeBtn = detailHead.createEl("button", {
      cls: "si-icon-btn",
      attr: { type: "button", "aria-label": "Close details" }
    });
    (0, import_obsidian10.setIcon)(closeBtn, "x");
    closeBtn.addEventListener("click", () => {
      this.selectedId = null;
      this.renderDetail();
      this.renderMain();
    });
    const preview = detail.createDiv({ cls: "si-detail-preview" });
    renderIcon(preview, def.id, 56);
    detail.createDiv({ cls: "si-detail-name", text: def.name });
    detail.createDiv({ cls: "si-detail-id" }).setText(def.id);
    const actions = detail.createDiv({ cls: "si-detail-actions" });
    const favBtn = actions.createEl("button", {
      cls: "si-btn" + (store.isFavorite(id) ? " is-active" : ""),
      attr: { type: "button" }
    });
    (0, import_obsidian10.setIcon)(favBtn, store.isFavorite(id) ? "star" : "star");
    favBtn.createSpan({ text: store.isFavorite(id) ? "Favorited" : "Favorite" });
    favBtn.addEventListener("click", () => {
      void store.toggleFavorite(id);
      this.renderDetail();
      this.renderMain();
    });
    const applyBtn = actions.createEl("button", { cls: "si-btn si-btn-primary", attr: { type: "button" } });
    applyBtn.createSpan({ text: "Apply to active note" });
    applyBtn.addEventListener("click", () => {
      void this.plugin.setOverrideForActiveFile(id);
    });
    const insertBtn = actions.createEl("button", { cls: "si-btn", attr: { type: "button" } });
    insertBtn.createSpan({ text: "Insert in note" });
    insertBtn.addEventListener("click", () => this.insertIconAtCursor(def));
    if (def.pack === "user") {
      const deleteBtn = actions.createEl("button", { cls: "si-btn is-danger", attr: { type: "button" } });
      (0, import_obsidian10.setIcon)(deleteBtn, "trash");
      deleteBtn.createSpan({ text: "Delete icon" });
      deleteBtn.addEventListener("click", () => void this.deleteUserIcon(def));
    }
    const copyRow = detail.createDiv({ cls: "si-detail-copy" });
    const copyName = copyRow.createEl("button", { cls: "si-btn si-btn-small", attr: { type: "button" } });
    copyName.createSpan({ text: "Copy name" });
    copyName.addEventListener("click", () => void navigator.clipboard.writeText(def.id));
    const copySvg = copyRow.createEl("button", { cls: "si-btn si-btn-small", attr: { type: "button" } });
    copySvg.createSpan({ text: "Copy SVG" });
    copySvg.addEventListener("click", () => void navigator.clipboard.writeText(svgForClipboard(def.svg)));
    const tagsSection = detail.createDiv({ cls: "si-detail-section" });
    tagsSection.createDiv({ cls: "si-detail-section-title", text: "Tags" });
    const tagWrap = tagsSection.createDiv({ cls: "si-tag-wrap" });
    const packTags = def.tags.slice(0, 8);
    for (const t of packTags) {
      tagWrap.createSpan({ cls: "si-tag is-pack", text: t });
    }
    for (const t of store.userTagsFor(id)) {
      const chip = tagWrap.createSpan({ cls: "si-tag" });
      chip.createSpan({ text: t });
      const x = chip.createSpan({ cls: "si-tag-x" });
      (0, import_obsidian10.setIcon)(x, "x");
      x.addEventListener("click", () => void store.removeUserTag(id, t));
    }
    const addInput = tagsSection.createEl("input", {
      cls: "si-text-input",
      attr: { placeholder: "add tag\u2026", spellcheck: "false" }
    });
    addInput.addEventListener("keydown", (ev) => {
      if (ev.key === "Enter" && addInput.value.trim()) {
        void store.addUserTag(id, addInput.value);
        addInput.value = "";
      }
    });
    const colSection = detail.createDiv({ cls: "si-detail-section" });
    colSection.createDiv({ cls: "si-detail-section-title", text: "Collections" });
    const colWrap = colSection.createDiv({ cls: "si-detail-cols" });
    for (const col of store.getSettings().collections) {
      const inCol = col.iconIds.includes(id);
      const item = colWrap.createEl("button", {
        cls: "si-btn si-btn-small" + (inCol ? " is-active" : ""),
        attr: { type: "button" }
      });
      item.createSpan({ text: `${inCol ? "\u2713 " : ""}${col.name}` });
      item.addEventListener("click", () => {
        void (inCol ? store.removeFromCollection(col.id, id) : store.addToCollection(col.id, id));
      });
    }
  }
  async promptText(placeholder, fallback) {
    return promptText(this.app, { title: placeholder, initial: fallback });
  }
  /* --- user icons ("My Icons") --------------------------------------------- */
  importSvgFiles() {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".svg,image/svg+xml";
    input.multiple = true;
    input.addEventListener("change", () => {
      const files = Array.from(input.files ?? []);
      if (!files.length) return;
      void (async () => {
        const entries = await Promise.all(
          files.map(async (f) => ({
            name: f.name.replace(/\.svg$/i, ""),
            svg: await f.text()
          }))
        );
        const added = await this.plugin.store.addUserIcons(entries);
        new import_obsidian10.Notice(`Added ${added} icon${added === 1 ? "" : "s"} to My Icons`);
      })();
    });
    input.click();
  }
  async pasteSvg() {
    const svg = await promptTextArea(this.app, {
      title: "Paste SVG code",
      placeholder: "<svg \u2026>\u2026</svg>  (Ctrl/Cmd+Enter to add)",
      okLabel: "Add icon"
    });
    if (!svg) return;
    const added = await this.plugin.store.addUserIcons([{ name: "pasted-icon", svg }]);
    new import_obsidian10.Notice(`Added ${added} icon${added === 1 ? "" : "s"} to My Icons`);
  }
  /** Insert the icon as inline SVG at the cursor of the user's note. */
  async insertIconAtCursor(icon) {
    const view = this.app.workspace.getActiveViewOfType(import_obsidian10.MarkdownView) ?? this.lastMarkdownView();
    if (!view) {
      new import_obsidian10.Notice("Open a note first.");
      return;
    }
    const size = await promptSize(this.app, { title: `Insert \u201C${icon.name}\u201D` });
    if (!size) return;
    view.editor.replaceSelection(svgForClipboard(icon.svg, size));
  }
  /**
   * The markdown view the user is most likely editing. The Icon Manager is
   * the active leaf while you click "Insert in note", so getActiveViewOfType
   * returns null — fall back to the most recently opened markdown file.
   */
  lastMarkdownView() {
    const leaves = this.app.workspace.getLeavesOfType("markdown");
    if (!leaves.length) return null;
    const last = this.app.workspace.getLastOpenFiles();
    for (const path of last) {
      const leaf = leaves.find((l) => l.view.file?.path === path);
      if (leaf) return leaf.view;
    }
    return leaves[leaves.length - 1].view;
  }
  async deleteUserIcon(def) {
    const ok = await confirmDialog(this.app, {
      title: `Delete \u201C${def.name}\u201D?`,
      message: "This removes your custom icon. This cannot be undone.",
      confirmLabel: "Delete",
      danger: true
    });
    if (!ok) return;
    await this.plugin.store.removeUserIcon(def.id);
    if (this.selectedId === def.id) this.selectedId = null;
  }
};

// src/ui/settingsTab.ts
var import_obsidian12 = require("obsidian");

// src/settings.ts
function mergeSettings(raw) {
  const base = JSON.parse(JSON.stringify(DEFAULT_SETTINGS));
  if (!raw || typeof raw !== "object") return base;
  const r = raw;
  for (const key of Object.keys(base)) {
    const v = r[key];
    if (v === void 0 || v === null) continue;
    const target = base[key];
    if (target && typeof target === "object" && !Array.isArray(target)) {
      base[key] = { ...target, ...v };
    } else if (Array.isArray(target)) {
      const arr = Array.isArray(v) ? v : [];
      base[key] = arr.filter(
        (item) => item && typeof item === "object"
      );
    } else {
      base[key] = v;
    }
  }
  return base;
}

// src/ui/ruleEditor.ts
var import_obsidian11 = require("obsidian");
var TYPE_OPS = {
  filename: ["equals", "contains", "startsWith", "endsWith", "matches"],
  path: ["equals", "contains", "startsWith", "endsWith", "matches"],
  extension: ["equals", "isIn", "isNotIn"],
  folder: ["isIn", "isNotIn", "contains", "matches"],
  tag: ["equals", "contains", "startsWith"],
  property: ["exists", "notExists", "equals", "contains"],
  heading: ["equals", "contains", "startsWith"],
  time: ["equals"]
};
var DAY_LABELS = ["S", "M", "T", "W", "T", "F", "S"];
var RuleEditModal = class extends import_obsidian11.Modal {
  constructor(app, store, getSettings, saveRule, existing) {
    super(app);
    this.store = store;
    this.getSettings = getSettings;
    this.saveRule = saveRule;
    this.rule = existing ? JSON.parse(JSON.stringify(existing)) : {
      id: uid("rule"),
      name: "New rule",
      enabled: true,
      match: "all",
      conditions: [],
      action: { type: "icon", iconId: "si-lucide-star" },
      createdAt: Date.now()
    };
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.addClass("si-rule-editor");
    const header = contentEl.createDiv({ cls: "si-rule-header" });
    const nameInput = header.createEl("input", {
      cls: "si-rule-name",
      attr: { placeholder: "Rule name", spellcheck: "false" },
      text: this.rule.name
    });
    nameInput.value = this.rule.name;
    nameInput.addEventListener("input", () => this.rule.name = nameInput.value || "Untitled rule");
    const enabledToggle = header.createEl("button", {
      cls: "si-toggle" + (this.rule.enabled ? " is-on" : ""),
      attr: { type: "button", "aria-label": "Enabled" }
    });
    enabledToggle.addEventListener("click", () => {
      this.rule.enabled = !this.rule.enabled;
      enabledToggle.toggleClass("is-on", this.rule.enabled);
    });
    const matchRow = contentEl.createDiv({ cls: "si-rule-match" });
    matchRow.createSpan({ cls: "si-label", text: "Match" });
    const matchSel = segmentedControl(
      [
        { value: "all", label: "All conditions" },
        { value: "any", label: "Any condition" }
      ],
      this.rule.match,
      (v) => {
        this.rule.match = v;
        this.refreshPreview();
      }
    );
    matchRow.appendChild(matchSel);
    const condSection = contentEl.createDiv({ cls: "si-rule-section" });
    const condHead = condSection.createDiv({ cls: "si-section-head" });
    condHead.createSpan({ cls: "si-section-title", text: "Conditions" });
    const addBtn = condHead.createEl("button", { cls: "si-btn si-btn-small", attr: { type: "button" } });
    addBtn.createSpan({ text: "+ Add condition" });
    addBtn.addEventListener("click", () => {
      this.rule.conditions.push({
        id: uid("cond"),
        type: "filename",
        op: "contains",
        value: ""
      });
      renderConditions(condSection);
      this.refreshPreview();
    });
    const condList = condSection.createDiv({ cls: "si-cond-list" });
    const renderConditions = (section) => {
      condList.empty();
      if (this.rule.conditions.length === 0) {
        condList.appendChild(emptyState("No conditions yet", "Add one \u2014 e.g. file name contains \u201Cnote\u201D."));
      }
      this.rule.conditions.forEach((cond, i) => {
        condList.appendChild(this.buildCondRow(cond, i, () => {
          this.rule.conditions.splice(i, 1);
          renderConditions(section);
          this.refreshPreview();
        }));
      });
    };
    renderConditions(condSection);
    const actionSection = contentEl.createDiv({ cls: "si-rule-section" });
    actionSection.createDiv({ cls: "si-section-title", text: "Action" });
    const actionWrap = actionSection.createDiv({ cls: "si-action-editor" });
    const renderAction = () => {
      actionWrap.empty();
      const seg = segmentedControl(
        [
          { value: "icon", label: "Set icon" },
          { value: "random", label: "Random from collection" },
          { value: "clear", label: "Use Obsidian default" }
        ],
        this.rule.action.type,
        (v) => {
          if (v === "icon") this.rule.action = { type: "icon", iconId: "si-lucide-star" };
          else if (v === "random") this.rule.action = { type: "random", collectionId: this.getSettings().collections[0]?.id ?? "" };
          else this.rule.action = { type: "clear" };
          renderAction();
          this.refreshPreview();
        }
      );
      actionWrap.appendChild(seg);
      if (this.rule.action.type === "icon") {
        const row = actionWrap.createDiv({ cls: "si-action-row" });
        const preview = row.createDiv({ cls: "si-action-preview" });
        const def = getIcon(this.rule.action.iconId);
        if (def) renderIcon(preview, def.id, 32);
        else preview.setText("?");
        const choose = row.createEl("button", { cls: "si-btn", attr: { type: "button" } });
        choose.createSpan({ text: def ? `Change icon (${def.name})` : "Choose icon\u2026" });
        choose.addEventListener("click", () => {
          new IconPickerModal(this.app, () => this.store, {
            title: "Icon for this rule",
            onPick: (icon) => {
              if (icon) {
                this.rule.action = { type: "icon", iconId: icon.id };
                renderAction();
                this.refreshPreview();
              }
            }
          }).open();
        });
      } else if (this.rule.action.type === "random") {
        const row = actionWrap.createDiv({ cls: "si-action-row" });
        row.createSpan({ cls: "si-label", text: "Collection" });
        const select = row.createEl("select", { cls: "dropdown" });
        const cols = this.getSettings().collections;
        if (cols.length === 0) {
          select.createEl("option", { text: "No collections yet \u2014 create one in the Manager", value: "" });
        }
        for (const c of cols) {
          select.createEl("option", { text: `${c.name} (${c.iconIds.length})`, value: c.id });
        }
        select.value = this.rule.action.collectionId;
        select.addEventListener("change", () => {
          this.rule.action = { type: "random", collectionId: select.value };
        });
      } else {
        actionWrap.createDiv({ cls: "si-hint", text: "The file/folder keeps Obsidian's built-in icon." });
      }
    };
    renderAction();
    const previewSection = contentEl.createDiv({ cls: "si-rule-section" });
    const previewHead = previewSection.createDiv({ cls: "si-section-head" });
    previewHead.createSpan({ cls: "si-section-title", text: "Live preview" });
    this.previewEl = previewSection.createDiv({ cls: "si-preview-list" });
    this.refreshPreview = debounce(() => this.renderPreview(), 180);
    this.refreshPreview();
    const footer = contentEl.createDiv({ cls: "si-rule-footer" });
    const cancel = footer.createEl("button", { cls: "si-btn", attr: { type: "button" } });
    cancel.createSpan({ text: "Cancel" });
    cancel.addEventListener("click", () => this.close());
    const save = footer.createEl("button", {
      cls: "si-btn si-btn-primary",
      attr: { type: "button" }
    });
    save.createSpan({ text: "Save rule" });
    save.addEventListener("click", async () => {
      if (!this.rule.name.trim()) {
        new import_obsidian11.Notice("Give the rule a name first.");
        return;
      }
      await this.saveRule(this.rule);
      new import_obsidian11.Notice(`Rule \u201C${this.rule.name}\u201D saved`);
      this.close();
    });
  }
  onClose() {
    this.contentEl.empty();
  }
  buildCondRow(cond, index, onRemove) {
    const row = document.createElement("div");
    row.className = "si-cond-row";
    row.dataset.index = String(index);
    const typeSel = row.createEl("select", { cls: "dropdown si-cond-type" });
    for (const t of Object.keys(TYPE_OPS)) {
      typeSel.createEl("option", { text: CONDITION_LABELS[t], value: t });
    }
    typeSel.value = cond.type;
    typeSel.addEventListener("change", () => {
      cond.type = typeSel.value;
      cond.op = TYPE_OPS[cond.type][0];
      cond.value = cond.value ?? "";
      this.rebuildRow(row, cond, index, onRemove);
      this.refreshPreview();
    });
    row.appendChild(typeSel);
    this.appendOpAndValue(row, cond, onRemove);
    const remove = row.createEl("button", {
      cls: "si-icon-btn si-cond-remove",
      attr: { type: "button", "aria-label": "Remove condition" }
    });
    (0, import_obsidian11.setIcon)(remove, "x");
    remove.addEventListener("click", onRemove);
    return row;
  }
  /** Rebuild a row in place after a type change. */
  rebuildRow(row, cond, index, onRemove) {
    row.empty();
    const typeSel = row.createEl("select", { cls: "dropdown si-cond-type" });
    for (const t of Object.keys(TYPE_OPS)) {
      typeSel.createEl("option", { text: CONDITION_LABELS[t], value: t });
    }
    typeSel.value = cond.type;
    typeSel.addEventListener("change", () => {
      cond.type = typeSel.value;
      cond.op = TYPE_OPS[cond.type][0];
      cond.value = cond.value ?? "";
      this.rebuildRow(row, cond, index, onRemove);
      this.refreshPreview();
    });
    row.appendChild(typeSel);
    this.appendOpAndValue(row, cond, onRemove);
    const remove = row.createEl("button", { cls: "si-icon-btn si-cond-remove", attr: { type: "button" } });
    (0, import_obsidian11.setIcon)(remove, "x");
    remove.addEventListener("click", onRemove);
  }
  appendOpAndValue(row, cond, _onRemove) {
    const ops = TYPE_OPS[cond.type];
    const opSel = row.createEl("select", { cls: "dropdown si-cond-op" });
    for (const op of ops) opSel.createEl("option", { text: OP_LABELS[op], value: op });
    if (!ops.includes(cond.op)) cond.op = ops[0];
    opSel.value = cond.op;
    row.appendChild(opSel);
    const valueWrap = row.createDiv({ cls: "si-cond-value" });
    const renderValues = () => {
      valueWrap.empty();
      if (cond.type === "time") {
        const daysWrap = valueWrap.createDiv({ cls: "si-day-chips" });
        for (let d = 0; d < 7; d++) {
          const chip = daysWrap.createEl("button", {
            cls: "si-day-chip" + (cond.days?.includes(d) ? " is-on" : ""),
            attr: { type: "button" },
            text: DAY_LABELS[d]
          });
          chip.addEventListener("click", () => {
            cond.days = cond.days ?? [];
            const i = cond.days.indexOf(d);
            if (i >= 0) cond.days.splice(i, 1);
            else cond.days.push(d);
            chip.toggleClass("is-on", cond.days.includes(d));
          });
        }
        const from = valueWrap.createEl("input", {
          cls: "si-text-input si-time-input",
          attr: { type: "time" }
        });
        from.value = cond.from ?? "";
        from.addEventListener("input", () => cond.from = from.value);
        valueWrap.appendChild(from);
        const to = valueWrap.createEl("input", {
          cls: "si-text-input si-time-input",
          attr: { type: "time" }
        });
        to.value = cond.to ?? "";
        to.addEventListener("input", () => cond.to = to.value);
        valueWrap.appendChild(to);
        return;
      }
      if (cond.type === "property") {
        const key = valueWrap.createEl("input", {
          cls: "si-text-input si-cond-key",
          attr: { placeholder: "property key (e.g. type)", spellcheck: "false" }
        });
        key.value = cond.key ?? "";
        key.addEventListener("input", () => cond.key = key.value);
        valueWrap.appendChild(key);
        if (cond.op === "equals" || cond.op === "contains") {
          const val = valueWrap.createEl("input", {
            cls: "si-text-input",
            attr: { placeholder: "value", spellcheck: "false" }
          });
          val.value = cond.value ?? "";
          val.addEventListener("input", () => {
            cond.value = val.value;
            this.refreshPreview();
          });
          valueWrap.appendChild(val);
        }
        return;
      }
      const valueInput = valueWrap.createEl("input", {
        cls: "si-text-input",
        attr: {
          placeholder: cond.type === "extension" ? "md, pdf, png (comma separated)" : "value",
          spellcheck: "false"
        }
      });
      valueInput.value = cond.value ?? "";
      valueInput.addEventListener("input", () => {
        cond.value = valueInput.value;
        this.refreshPreview();
      });
      valueWrap.appendChild(valueInput);
    };
    renderValues();
    opSel.addEventListener("change", () => {
      cond.op = opSel.value;
      renderValues();
      this.refreshPreview();
    });
    row.appendChild(valueWrap);
  }
  renderPreview() {
    this.previewEl.empty();
    const files = this.app.vault.getFiles();
    const matches = [];
    let evaluated = 0;
    for (const file of files) {
      const ctx = buildFileContext(file, this.app);
      const count = this.rule.conditions.filter((c) => evaluateCondition(c, ctx)).length;
      const total = this.rule.conditions.length;
      if (total === 0) break;
      const matched = this.rule.match === "all" ? count === total : count > 0;
      if (!matched) continue;
      evaluated++;
      matches.push({
        name: file.path,
        iconId: this.rule.action.type === "icon" ? this.rule.action.iconId : null,
        count,
        isFolder: false
      });
      if (matches.length >= 20) break;
    }
    if (this.rule.conditions.length === 0) {
      this.previewEl.appendChild(emptyState("Add a condition to see matching files", "Matches update as you type."));
      return;
    }
    const head = this.previewEl.createDiv({ cls: "si-preview-head" });
    head.createSpan({
      cls: "si-preview-count",
      text: `Matches ${matches.length >= 20 ? "20+ of " : ""}${evaluated} file${evaluated === 1 ? "" : "s"} in this vault`
    });
    void head;
    if (matches.length === 0) {
      this.previewEl.appendChild(emptyState("Nothing matches yet", "Loosen the conditions or add another."));
      return;
    }
    const list = this.previewEl.createDiv({ cls: "si-preview-items" });
    for (const m of matches) {
      const item = list.createDiv({ cls: "si-preview-item" });
      const ic = item.createSpan({ cls: "si-preview-icon" });
      if (m.iconId) {
        try {
          renderIcon(ic, m.iconId);
        } catch {
        }
      }
      item.createSpan({ cls: "si-preview-name", text: m.name });
      item.createSpan({ cls: "si-preview-count-badge", text: `${m.count}/${this.rule.conditions.length}` });
    }
  }
};

// src/ui/settingsTab.ts
function summarizeRule(rule) {
  if (rule.conditions.length === 0) return "matches everything";
  const parts = rule.conditions.map((c) => {
    switch (c.type) {
      case "time":
        const days = c.days?.length ? c.days.map((d) => "SMTWTFS"[d]).join("") + " " : "";
        return `time ${days}${c.from ?? "\u2026"}\u2013${c.to ?? "\u2026"}`;
      case "property":
        return `property ${c.key} ${c.op} ${c.value ?? ""}`.trim();
      default:
        return `${c.type} ${c.op} \u201C${c.value ?? ""}\u201D`;
    }
  });
  return parts.join(rule.match === "all" ? " AND " : " OR ");
}
var StarIconsSettingTab = class extends import_obsidian12.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  display() {
    const { containerEl } = this;
    containerEl.empty();
    containerEl.addClass("si-settings");
    this.renderGeneral();
    this.renderPacks();
    this.renderFileTypes();
    this.renderRules();
    this.renderCollections();
    this.renderData();
  }
  /* --- general ------------------------------------------------------------ */
  renderGeneral() {
    const { containerEl } = this;
    const s = this.plugin.settings;
    new import_obsidian12.Setting(containerEl).setName("Where icons appear").setHeading();
    new import_obsidian12.Setting(containerEl).setName("File explorer icons").setDesc("Show resolved icons on files and folders in the sidebar.").addToggle((t) => t.setValue(s.fileExplorerIcons).onChange(async (v) => {
      s.fileExplorerIcons = v;
      await this.plugin.saveSettings();
      this.plugin.refreshIcons();
    }));
    new import_obsidian12.Setting(containerEl).setName("Tab icons").setDesc("Show icons in the tab headers of open notes.").addToggle((t) => t.setValue(s.tabIcons).onChange(async (v) => {
      s.tabIcons = v;
      await this.plugin.saveSettings();
      this.plugin.refreshIcons();
    }));
    new import_obsidian12.Setting(containerEl).setName("Icon above note title").setDesc("Show the resolved icon above the note title (reading view).").addToggle((t) => t.setValue(s.inlineTitleIcons).onChange(async (v) => {
      s.inlineTitleIcons = v;
      await this.plugin.saveSettings();
      this.plugin.refreshIcons();
    }));
    new import_obsidian12.Setting(containerEl).setName("\u2026also in edit mode").setDesc("Show the title icon in the editor too (inserted as non-editable content).").setDisabled(!s.inlineTitleIcons).addToggle((t) => t.setValue(s.inlineTitleEditMode).onChange(async (v) => {
      s.inlineTitleEditMode = v;
      await this.plugin.saveSettings();
      this.plugin.refreshIcons();
    }));
    new import_obsidian12.Setting(containerEl).setName("Icon source tooltips").setDesc("Hover a file to see which icon applies and which rule decided it.").addToggle((t) => t.setValue(s.showSourceTooltips).onChange(async (v) => {
      s.showSourceTooltips = v;
      await this.plugin.saveSettings();
      this.plugin.refreshIcons();
    }));
    new import_obsidian12.Setting(containerEl).setName("Status bar indicator").setDesc("Show the active note's icon + source in the status bar.").addToggle((t) => t.setValue(s.statusBarIndicator).onChange(async (v) => {
      s.statusBarIndicator = v;
      await this.plugin.saveSettings();
      this.plugin.updateStatusBar();
    }));
    new import_obsidian12.Setting(containerEl).setName("Refresh icons").setDesc("Re-apply icons everywhere (after Obsidian updates or UI glitches).").addButton((b) => b.setButtonText("Refresh now").onClick(() => {
      this.plugin.refreshIcons();
      new import_obsidian12.Notice("Icons refreshed");
    }));
  }
  /* --- packs ---------------------------------------------------------------- */
  renderPacks() {
    const { containerEl } = this;
    const s = this.plugin.settings;
    new import_obsidian12.Setting(containerEl).setName("Icon packs").setHeading();
    containerEl.createDiv({
      cls: "setting-item-description",
      text: `${this.plugin.store.totalCount().toLocaleString()} icons available \u2014 packs load on demand when enabled, no network needed.`
    });
    const descriptions = {
      lucide: "The de-facto Obsidian icon set. 2,025 icons, official tags.",
      material: "Google Material Symbols \u2014 full rounded set (base + fill variants).",
      "material-outlined": "The same Material set in the outlined weight.",
      "material-sharp": "The same Material set in the sharp weight.",
      star: "Original hand-crafted star icons \u2014 the Star Icons identity.",
      tabler: "Tabler outline \u2014 5,130 clean, modern icons with categories.",
      "tabler-filled": "Tabler filled \u2014 1,054 solid versions of the outline set.",
      unicons: "Iconscout Unicons (line style) \u2014 1,215 playful icons.",
      "unicons-solid": "Unicons in the solid style.",
      "unicons-monochrome": "Unicons in the monochrome style.",
      "unicons-thinline": "Unicons in the thinline style.",
      remix: "Remix Icon \u2014 3,078 icons (line + fill) across 20 categories.",
      phosphor: "Phosphor (regular weight) \u2014 1,512 geometric icons.",
      "phosphor-bold": "Phosphor in the bold weight.",
      "phosphor-fill": "Phosphor in the fill weight.",
      "phosphor-light": "Phosphor in the light weight.",
      "phosphor-thin": "Phosphor in the thin weight.",
      "phosphor-duotone": "Phosphor in the duotone weight (two-tone).",
      bootstrap: "Bootstrap Icons \u2014 2,078 crisp, rounded icons.",
      boxicons: "Boxicons \u2014 814 filled, rounded web icons.",
      "boxicons-solid": "Boxicons in the solid style.",
      "boxicons-logos": "Boxicons brand logos.",
      heroicons: "Heroicons \u2014 324 outline icons by the Tailwind team.",
      "heroicons-solid": "Heroicons in the solid style.",
      fontawesome: "Font Awesome Free \u2014 2,274 solid + regular icons (CC BY 4.0).",
      "simple-icons": "Simple Icons \u2014 3,453 brand logos (CC0).",
      ionicons: "Ionicons \u2014 1,357 icons (base + outline + sharp).",
      antd: "Ant Design Icons \u2014 outlined/filled/twotone variants.",
      "line-awesome": "Line Awesome \u2014 1,544 line-style icons (includes brands).",
      eva: "Eva Icons \u2014 490 outline + fill icons.",
      octicons: "Octicons \u2014 743 GitHub-style icons (all sizes).",
      cssgg: "CSS.gg \u2014 704 hand-crafted stroke icons.",
      openmoji: "OpenMoji Color \u2014 1,718 full-color emoji SVGs (CC BY-SA 4.0).",
      "openmoji-black": "OpenMoji monochrome \u2014 1,860 line-drawn emoji.",
      twemoji: "Twemoji \u2014 4,009 full-color emoji SVGs (CC BY 4.0).",
      fluent: "Fluent Emoji \u2014 3,145 full-color flat emoji (MIT).",
      animals: "Emoji animals \u2014 pets & wildlife, rendered with your system emoji font.",
      nature: "Emoji flowers & plants \u2014 from your system emoji font.",
      science: "Emoji science & space \u2014 from your system emoji font."
    };
    for (const group of PACK_GROUPS) {
      const details = containerEl.createEl("details", { cls: "si-pack-group" });
      if (group.open) details.setAttr("open", "");
      const summary = details.createEl("summary", { cls: "si-pack-group-head" });
      summary.createSpan({ text: group.title });
      summary.createSpan({ cls: "si-pack-group-meta", text: `${group.packs.length} packs` });
      for (const pack of group.packs) {
        const setting = new import_obsidian12.Setting(details).setName(PACK_LABELS[pack] ?? pack).setDesc(`${descriptions[pack] ?? "Icon pack"} \xB7 v${this.plugin.store.getPackVersion(pack)} \xB7 ${this.plugin.store.getPackCount(pack).toLocaleString()} icons`).addToggle(
          (t) => t.setValue(s.enabledPacks[pack] !== false).onChange(async (v) => {
            s.enabledPacks[pack] = v;
            await this.plugin.saveSettings();
            if (v) await this.plugin.store.loadPack(pack);
            this.plugin.store.notify();
            this.plugin.refreshIcons();
          })
        );
        const preview = setting.settingEl.createDiv({ cls: "si-pack-preview" });
        const samples = ["home", "folder", "star", "heart", "settings", "file-text", "music", "cloud"];
        for (const name of samples) {
          const def = getIcon(`si-${pack}-${name}`);
          if (def) {
            const ic = preview.createSpan({ cls: "si-pack-sample" });
            renderIcon(ic, def.id, 16);
          }
        }
      }
    }
  }
  /* --- file types ------------------------------------------------------------ */
  renderFileTypes() {
    const { containerEl } = this;
    const s = this.plugin.settings;
    new import_obsidian12.Setting(containerEl).setName("File type icons").setHeading();
    containerEl.createDiv({
      cls: "setting-item-description",
      text: "Fallback icons for file extensions (used when no rule matches). Priority: override > rules > this > default."
    });
    const listEl = containerEl.createDiv({ cls: "si-filetype-list" });
    const render = () => {
      listEl.empty();
      const defaultRow = this.fileTypeRow(listEl, "*", s.defaultIcon ?? null, "Default icon");
      void defaultRow;
      for (const [ext, iconId2] of Object.entries(s.fileTypeDefaults)) {
        this.fileTypeRow(listEl, ext, iconId2, `.${ext} files`);
      }
      const addRow = listEl.createDiv({ cls: "si-filetype-add" });
      const input = addRow.createEl("input", {
        cls: "si-text-input",
        attr: { placeholder: "ext (e.g. md)", spellcheck: "false" }
      });
      const pick = addRow.createEl("button", { cls: "si-btn", attr: { type: "button" } });
      pick.createSpan({ text: "Add" });
      pick.addEventListener("click", () => {
        const ext = normalizeExt(input.value);
        if (!ext) return;
        new IconPickerModal(this.app, () => this.plugin.store, {
          title: `Icon for .${ext} files`,
          onPick: (icon) => {
            if (!icon) return;
            s.fileTypeDefaults[ext] = icon.id;
            void this.plugin.saveSettings().then(() => {
              this.plugin.refreshIcons();
              render();
            });
          }
        }).open();
      });
    };
    render();
  }
  fileTypeRow(listEl, ext, iconId2, label) {
    const s = this.plugin.settings;
    const row = listEl.createDiv({ cls: "si-filetype-row" });
    const labelEl = row.createSpan({ cls: "si-filetype-label", text: label });
    void labelEl;
    const preview = row.createSpan({ cls: "si-filetype-icon" });
    if (iconId2) renderIcon(preview, iconId2, 18);
    else preview.setText("\u2014");
    const change = row.createEl("button", { cls: "si-btn si-btn-small", attr: { type: "button" } });
    change.createSpan({ text: "Change" });
    change.addEventListener("click", () => {
      new IconPickerModal(this.app, () => this.plugin.store, {
        title: `Icon for ${label}`,
        onPick: (icon) => {
          if (ext === "*") {
            s.defaultIcon = icon ? icon.id : null;
          } else if (icon) {
            s.fileTypeDefaults[ext] = icon.id;
          } else {
            delete s.fileTypeDefaults[ext];
          }
          void this.plugin.saveSettings().then(() => {
            this.plugin.refreshIcons();
            this.display();
          });
        }
      }).open();
    });
    if (ext !== "*") {
      const remove = row.createEl("button", { cls: "si-icon-btn", attr: { type: "button" } });
      (0, import_obsidian12.setIcon)(remove, "x");
      remove.addEventListener("click", async () => {
        delete s.fileTypeDefaults[ext];
        await this.plugin.saveSettings();
        this.plugin.refreshIcons();
        this.display();
      });
    }
  }
  /* --- rules ----------------------------------------------------------------- */
  renderRules() {
    const { containerEl } = this;
    const s = this.plugin.settings;
    new import_obsidian12.Setting(containerEl).setName("Rules").setHeading();
    containerEl.createDiv({
      cls: "setting-item-description",
      text: "Rules run top-to-bottom; the first enabled match wins. Drag to reorder."
    });
    const listEl = containerEl.createDiv({ cls: "si-rule-list" });
    const render = () => {
      listEl.empty();
      if (s.rules.length === 0) {
        listEl.createDiv({ cls: "si-empty", text: "No rules yet \u2014 add your first rule" });
      }
      s.rules.forEach((rule, index) => {
        const row = listEl.createDiv({
          cls: "si-rule-row",
          attr: { draggable: "true", "data-index": String(index) }
        });
        const handle = row.createSpan({ cls: "si-drag-handle" });
        (0, import_obsidian12.setIcon)(handle, "grip-vertical");
        const toggle = row.createEl("button", {
          cls: "si-toggle" + (rule.enabled ? " is-on" : ""),
          attr: { type: "button", "aria-label": "Enable rule" }
        });
        toggle.addEventListener("click", async () => {
          rule.enabled = !rule.enabled;
          await this.plugin.saveSettings();
          this.plugin.refreshIcons();
          render();
        });
        const body = row.createDiv({ cls: "si-rule-body" });
        body.createDiv({ cls: "si-rule-name", text: rule.name });
        body.createDiv({ cls: "si-rule-summary", text: summarizeRule(rule) });
        const actionPreview = row.createSpan({ cls: "si-rule-action" });
        const action = rule.action;
        if (action.type === "icon") {
          renderIcon(actionPreview, action.iconId, 18);
        } else if (action.type === "random") {
          const col = s.collections.find((c) => c.id === action.collectionId);
          actionPreview.setText(`\u{1F3B2} ${col?.name ?? "collection"}`);
        } else {
          actionPreview.setText("default");
        }
        const edit = row.createEl("button", { cls: "si-icon-btn", attr: { type: "button" } });
        (0, import_obsidian12.setIcon)(edit, "pencil");
        edit.addEventListener("click", () => {
          new RuleEditModal(this.app, this.plugin.store, () => this.plugin.settings, async (r) => {
            const i = s.rules.findIndex((x) => x.id === r.id);
            if (i >= 0) s.rules[i] = r;
            await this.plugin.saveSettings();
            this.plugin.refreshIcons();
            render();
          }, rule).open();
        });
        const remove = row.createEl("button", { cls: "si-icon-btn", attr: { type: "button" } });
        (0, import_obsidian12.setIcon)(remove, "trash");
        remove.addEventListener("click", async () => {
          s.rules = s.rules.filter((x) => x.id !== rule.id);
          await this.plugin.saveSettings();
          this.plugin.refreshIcons();
          render();
        });
        row.appendChild(handle);
        row.appendChild(toggle);
        row.appendChild(body);
        row.appendChild(actionPreview);
        row.appendChild(edit);
        row.appendChild(remove);
      });
      makeSortable(listEl, {
        onReorder: async (from, to) => {
          const [moved] = s.rules.splice(from, 1);
          s.rules.splice(to, 0, moved);
          await this.plugin.saveSettings();
          this.plugin.refreshIcons();
          render();
        }
      });
    };
    render();
    new import_obsidian12.Setting(containerEl).addButton(
      (b) => b.setButtonText("\uFF0B Add rule").setCta().onClick(() => {
        new RuleEditModal(this.app, this.plugin.store, () => this.plugin.settings, async (r) => {
          s.rules.push(r);
          await this.plugin.saveSettings();
          this.plugin.refreshIcons();
          this.display();
        }).open();
      })
    );
  }
  /* --- collections -------------------------------------------------------------- */
  renderCollections() {
    const { containerEl } = this;
    const s = this.plugin.settings;
    new import_obsidian12.Setting(containerEl).setName("Collections").setHeading();
    containerEl.createDiv({
      cls: "setting-item-description",
      text: "Curate icon sets here; drag & drop in the Icon Manager. Used by \u201Crandom\u201D rule actions."
    });
    const list = containerEl.createDiv({ cls: "si-col-summary" });
    if (s.collections.length === 0) {
      list.createDiv({ cls: "si-empty", text: "No collections yet" });
    }
    for (const col of s.collections) {
      const row = list.createDiv({ cls: "si-col-summary-row" });
      const icon = row.createSpan({ cls: "si-side-item-icon" });
      renderIcon(icon, col.iconIds[0] ?? "si-lucide-folder");
      row.createSpan({ cls: "si-col-summary-name", text: col.name });
      row.createSpan({ cls: "si-col-summary-count", text: `${col.iconIds.length} icons` });
      const open = row.createEl("button", { cls: "si-btn si-btn-small", attr: { type: "button" } });
      open.createSpan({ text: "Manage" });
      open.addEventListener("click", () => void this.plugin.openManager());
    }
    new import_obsidian12.Setting(containerEl).addButton(
      (b) => b.setButtonText("Open Icon Manager").onClick(() => void this.plugin.openManager())
    );
  }
  /* --- data ------------------------------------------------------------------------ */
  renderData() {
    const { containerEl } = this;
    new import_obsidian12.Setting(containerEl).setName("Data").setHeading();
    new import_obsidian12.Setting(containerEl).setName("Export").setDesc("Download your overrides, rules, collections, favorites and tags as JSON.").addButton(
      (b) => b.setButtonText("Export JSON").onClick(() => {
        downloadJson("star-icons-settings.json", this.plugin.settings);
      })
    );
    new import_obsidian12.Setting(containerEl).setName("Import").setDesc("Restore from an exported JSON file.").addButton((b) => {
      b.setButtonText("Import JSON").onClick(() => {
        const input = document.createElement("input");
        input.type = "file";
        input.accept = "application/json";
        input.addEventListener("change", async () => {
          const file = input.files?.[0];
          if (!file) return;
          try {
            const text = await file.text();
            this.plugin.settings = mergeSettings(JSON.parse(text));
            await this.plugin.saveSettings();
            this.plugin.refreshIcons();
            this.display();
            new import_obsidian12.Notice("Settings imported");
          } catch {
            new import_obsidian12.Notice("Could not parse that JSON file");
          }
        });
        input.click();
      });
    });
    new import_obsidian12.Setting(containerEl).setName("Reset").setDesc("Restore factory defaults (favorites, rules, collections\u2026).").addButton(
      (b) => b.setButtonText("Reset all").setWarning().onClick(async () => {
        const confirmed = await confirmDialog(this.app, {
          title: "Reset all Star Icons settings?",
          message: "This cannot be undone.",
          confirmLabel: "Reset all",
          danger: true
        });
        if (!confirmed) return;
        this.plugin.settings = mergeSettings(void 0);
        await this.plugin.saveSettings();
        this.plugin.refreshIcons();
        this.display();
      })
    );
    new import_obsidian12.Setting(containerEl).setName("Report a bug").setDesc("Copy a diagnostic report (versions, platform, pack state) to paste into an issue.").addButton(
      (b) => b.setButtonText("Open report dialog").onClick(() => {
        new ReportBugModal(this.app, {
          pluginVersion: this.plugin.manifest.version,
          appVersion: obsidianVersion(this.app),
          packs: ALL_PACKS.length,
          enabledPacks: ALL_PACKS.filter((p) => this.plugin.settings.enabledPacks[p] !== false).length,
          icons: this.plugin.store.totalCount(),
          reportUrl: this.plugin.settings.reportUrl || DEFAULT_REPORT_URL
        }).open();
      })
    );
    new import_obsidian12.Setting(containerEl).setName("Issue tracker URL (optional)").setDesc("If set, the bug report dialog gets an \u201COpen issue page\u201D button.").addText(
      (t) => t.setPlaceholder("https://github.com/you/star-icons/issues").setValue(this.plugin.settings.reportUrl).onChange(async (v) => {
        this.plugin.settings.reportUrl = v.trim();
        await this.plugin.saveSettings();
      })
    );
  }
};

// src/main.ts
var StarIconsPlugin = class extends import_obsidian13.Plugin {
  constructor() {
    super(...arguments);
    this.statusBarEl = null;
    /* --- ribbon ------------------------------------------------------------- */
    this.ribbonAdded = false;
  }
  async onload() {
    this.settings = mergeSettings(await this.loadData());
    this.store = new IconStore(
      this.app,
      () => this.manifest,
      () => this.settings,
      () => this.saveSettings()
    );
    this.store.registerIcons();
    this.store.mountUserIcons();
    this.applier = new IconApplier(this, this.app);
    this.registerView(ICON_MANAGER_VIEW_TYPE, (leaf) => new IconManagerView(leaf, this));
    this.ensureRibbonIcon();
    this.registerCommands();
    this.registerMenus();
    this.registerEvents();
    this.addSettingTab(new StarIconsSettingTab(this.app, this));
    if (this.settings.statusBarIndicator) this.initStatusBar();
    void this.store.loadManifest().then(() => this.store.loadEnabledPacks()).then(() => this.refreshIcons()).catch((err) => console.warn("[Star Icons] background pack load failed", err));
    this.app.workspace.onLayoutReady(() => this.refreshIcons());
  }
  onunload() {
    this.applier.dispose();
    this.app.workspace.detachLeavesOfType(ICON_MANAGER_VIEW_TYPE);
  }
  /**
   * Add the plugin icon to the ribbon, verifying the button actually got
   * attached to the DOM and retrying with built-in icons until one sticks.
   * (Obsidian can silently skip an icon if the ribbon isn't ready yet.)
   */
  ensureRibbonIcon() {
    const tryAdd = (icon) => {
      try {
        const el = this.addRibbonIcon(icon, "Star Icons \u2014 open the Icon Manager", () => {
          void this.openManager();
        });
        if (el && !el.isConnected) {
          el.remove();
          return false;
        }
        this.ribbonAdded = true;
        return true;
      } catch {
        return false;
      }
    };
    const attempt = () => {
      if (this.ribbonAdded) return;
      const icons = [brandIconId(), "star", "sparkles", "settings"];
      for (const icon of icons) {
        if (tryAdd(icon)) return;
      }
    };
    attempt();
    this.app.workspace.onLayoutReady(() => attempt());
    setTimeout(() => attempt(), 1500);
  }
  /* --- persistence ------------------------------------------------------- */
  async saveSettings() {
    await this.saveData(this.settings);
  }
  /* --- actions ----------------------------------------------------------- */
  /** Re-apply icons to the explorer, tabs, titles and status bar. */
  refreshIcons() {
    this.applier.refreshAll();
    this.updateStatusBar();
  }
  async openManager() {
    const existing = this.app.workspace.getLeavesOfType(ICON_MANAGER_VIEW_TYPE);
    if (existing.length > 0) {
      this.app.workspace.revealLeaf(existing[0]);
      return;
    }
    const leaf = this.app.workspace.getRightLeaf(false);
    if (!leaf) {
      new import_obsidian13.Notice("Could not open the Icon Manager.");
      return;
    }
    await leaf.setViewState({ type: ICON_MANAGER_VIEW_TYPE, active: true });
    this.app.workspace.revealLeaf(leaf);
  }
  async setOverrideForActiveFile(iconId2) {
    const file = this.lastActiveFile();
    if (!file) {
      new import_obsidian13.Notice("No active file.");
      return;
    }
    this.settings.overrides[file.path] = iconId2;
    await this.saveSettings();
    this.refreshIcons();
    new import_obsidian13.Notice(`Icon set for \u201C${file.basename}\u201D`);
  }
  /**
   * The file the user is actually working on. When triggered from the Icon
   * Manager (right sidebar) the manager itself is the active leaf, so
   * getActiveFile() returns null — fall back to the most recently opened file.
   */
  lastActiveFile() {
    const active = this.app.workspace.getActiveFile();
    if (active) return active;
    for (const path of this.app.workspace.getLastOpenFiles()) {
      const file = this.app.vault.getFileByPath(path);
      if (file) return file;
    }
    return null;
  }
  async pickIconFor(file) {
    const hasOverride = !!this.settings.overrides[file.path];
    new IconPickerModal(this.app, () => this.store, {
      title: `Icon for \u201C${file.name}\u201D`,
      allowNone: hasOverride,
      onPick: async (icon) => {
        if (icon) this.settings.overrides[file.path] = icon.id;
        else delete this.settings.overrides[file.path];
        await this.saveSettings();
        this.refreshIcons();
      }
    }).open();
  }
  async copyIconName(file) {
    const res = this.applier.resolve(file);
    const id = res.iconId ?? "default";
    await navigator.clipboard.writeText(id);
    new import_obsidian13.Notice(`Copied ${id}`);
  }
  /* --- status bar -------------------------------------------------------- */
  initStatusBar() {
    this.statusBarEl = this.addStatusBarItem();
    this.statusBarEl.addClass("si-status");
    this.statusBarEl.setAttribute("aria-label", "Star Icons \u2014 click to open manager");
    this.statusBarEl.addEventListener("click", () => void this.openManager());
    this.updateStatusBar();
  }
  updateStatusBar() {
    if (!this.statusBarEl) return;
    this.statusBarEl.empty();
    const file = this.app.workspace.getActiveFile();
    if (file) {
      const res = this.applier.resolve(file);
      if (res.iconId) {
        const iconEl2 = this.statusBarEl.createSpan({ cls: "si-status-icon" });
        try {
          (0, import_obsidian13.setIcon)(iconEl2, res.iconId);
        } catch {
        }
        iconEl2.querySelector("svg")?.setAttribute("width", "14");
        iconEl2.querySelector("svg")?.setAttribute("height", "14");
        this.statusBarEl.createSpan({ cls: "si-status-text", text: res.detail });
        this.statusBarEl.title = `${prettyIconName(res.iconId)} \u2014 ${res.detail}`;
        return;
      }
    }
    const iconEl = this.statusBarEl.createSpan({ cls: "si-status-icon" });
    try {
      (0, import_obsidian13.setIcon)(iconEl, brandIconId());
    } catch {
    }
    iconEl.querySelector("svg")?.setAttribute("width", "14");
    iconEl.querySelector("svg")?.setAttribute("height", "14");
    this.statusBarEl.createSpan({ cls: "si-status-text", text: "Star Icons" });
  }
  /* --- registration ------------------------------------------------------ */
  registerCommands() {
    this.addCommand({
      id: "open-manager",
      name: "Open the Icon Manager",
      callback: () => void this.openManager()
    });
    this.addCommand({
      id: "set-icon-active-file",
      name: "Set icon for the active file\u2026",
      callback: () => {
        const file = this.app.workspace.getActiveFile();
        if (file) void this.pickIconFor(file);
      }
    });
    this.addCommand({
      id: "remove-icon-active-file",
      name: "Remove icon from the active file",
      callback: async () => {
        const file = this.app.workspace.getActiveFile();
        if (!file) return;
        delete this.settings.overrides[file.path];
        await this.saveSettings();
        this.refreshIcons();
      }
    });
    this.addCommand({
      id: "copy-icon-name-active-file",
      name: "Copy the active file's icon name",
      callback: () => {
        const file = this.app.workspace.getActiveFile();
        if (file) void this.copyIconName(file);
      }
    });
    this.addCommand({
      id: "pick-and-copy-icon",
      name: "Pick an icon and copy its name",
      callback: () => {
        new IconPickerModal(this.app, () => this.store, {
          title: "Copy an icon name",
          onPick: async (icon) => {
            if (!icon) return;
            await navigator.clipboard.writeText(icon.id);
            new import_obsidian13.Notice(`Copied ${icon.id}`);
          }
        }).open();
      }
    });
    this.addCommand({
      id: "refresh-icons",
      name: "Refresh icons everywhere",
      callback: () => {
        this.refreshIcons();
        new import_obsidian13.Notice("Icons refreshed");
      }
    });
    this.addCommand({
      id: "insert-icon-at-cursor",
      name: "Insert an icon at the cursor",
      editorCallback: (editor) => {
        new IconPickerModal(this.app, () => this.store, {
          title: "Insert an icon",
          onPick: async (icon) => {
            if (!icon) return;
            const size = await promptSize(this.app, { title: `Insert \u201C${icon.name}\u201D` });
            if (!size) return;
            editor.replaceSelection(svgForClipboard(icon.svg, size));
          }
        }).open();
      }
    });
    this.addCommand({
      id: "report-bug",
      name: "Report a bug\u2026",
      callback: () => {
        new ReportBugModal(this.app, {
          pluginVersion: this.manifest.version,
          appVersion: obsidianVersion(this.app),
          packs: ALL_PACKS.length,
          enabledPacks: ALL_PACKS.filter((p) => this.settings.enabledPacks[p] !== false).length,
          icons: this.store.totalCount(),
          reportUrl: this.settings.reportUrl || DEFAULT_REPORT_URL
        }).open();
      }
    });
    this.addCommand({
      id: "delete-all-user-tags",
      name: "Delete all user tags",
      callback: async () => {
        const ok = await confirmDialog(this.app, {
          title: "Delete all user tags?",
          message: "Every custom tag will be removed from all icons.",
          confirmLabel: "Delete all",
          danger: true
        });
        if (ok) await this.store.clearAllUserTags();
      }
    });
  }
  registerMenus() {
    this.registerEvent(
      this.app.workspace.on("file-menu", (menu, file) => {
        if (!(file instanceof import_obsidian13.TFile) && !(file instanceof import_obsidian13.TFolder)) return;
        menu.addSeparator();
        menu.addItem(
          (item) => item.setTitle("Set icon\u2026").setIcon(brandIconId()).onClick(() => void this.pickIconFor(file))
        );
        menu.addItem(
          (item) => item.setTitle("Copy icon name").setIcon("copy").onClick(() => void this.copyIconName(file))
        );
        if (this.settings.overrides[file.path]) {
          menu.addItem(
            (item) => item.setTitle("Remove icon override").setIcon("trash").onClick(async () => {
              delete this.settings.overrides[file.path];
              await this.saveSettings();
              this.refreshIcons();
            })
          );
        }
      })
    );
    this.registerEvent(
      this.app.workspace.on("editor-menu", (menu) => {
        const file = this.app.workspace.getActiveFile();
        if (!file) return;
        menu.addItem(
          (item) => item.setTitle("Set icon for this note\u2026").setIcon(brandIconId()).onClick(() => void this.pickIconFor(file))
        );
      })
    );
  }
  registerEvents() {
    const refresh = debounce(() => this.refreshIcons(), 200);
    this.registerEvent(this.app.workspace.on("layout-change", refresh));
    this.registerEvent(this.app.workspace.on("file-open", refresh));
    this.registerEvent(this.app.vault.on("create", refresh));
    this.registerEvent(this.app.vault.on("delete", refresh));
    this.registerEvent(this.app.vault.on("rename", refresh));
    this.registerEvent(this.app.vault.on("modify", refresh));
    this.registerEvent(this.app.metadataCache.on("changed", refresh));
  }
};
var main_default = StarIconsPlugin;
